# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Client base — transaction infrastructure and fail-closed state loading."""

from __future__ import annotations

import copy
import math
import subprocess
import uuid
from collections.abc import Generator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from cascade.core.cascade import Cascade
from cascade.core.node import Node
from cascade.core.state import NodeState
from cascade.errors import StorageCorruptionError
from cascade.events import EventType, reservation_activity
from cascade.storage.file_storage import FileStorage
from cascade.storage.protocol import StorageProtocol
from cascade.types import (
    Context,
    Result,
)


class _Tx:
    """Mutation transaction — holds graph, handles emit/save/op_id."""

    def __init__(self, graph: Cascade, storage: StorageProtocol, op_id: str | None):
        self.graph = graph
        self._storage = storage
        self._op_id = op_id
        self._dirty = False
        self._trace_id = uuid.uuid4().hex
        self._task_inputs = {
            node.id: copy.deepcopy((node.task_input, node.publication, node.required_tier))
            for node in graph.nodes.values()
            if node.task_input is not None
        }

    def _validate_task_inputs(self) -> None:
        for node_id, expected in self._task_inputs.items():
            node = self.graph.nodes.get(node_id)
            if node is None or (node.task_input, node.publication, node.required_tier) != expected:
                raise ValueError(
                    "Published task inputs are immutable; cancel and publish a replacement"
                )
        for node in self.graph.nodes.values():
            if node.task_input is not None:
                actual = {a for a, b in self.graph.contracts if b == node.id}
                if actual != set(node.task_input["brief"]["dependencies"]):
                    raise ValueError(
                        "Published task dependencies are immutable; publish a replacement"
                    )

    def emit(self, event_type: EventType, **data: Any) -> None:
        self._validate_task_inputs()
        self._storage.events.emit(
            event_type,
            logical_ts=self._storage.next_lamport(),
            trace_id=self._trace_id,
            epoch=self.graph.epoch,
            **data,
        )
        self._dirty = True

    def save(self) -> None:
        self._validate_task_inputs()
        self._storage.save(self.graph)

    def ok(self, result: Result) -> Result:
        """Finalize a successful mutation: save graph, record op, return result."""
        if self._dirty:
            self._storage.save(self.graph)
        if self._op_id is not None:
            self._storage.ops.record(self._op_id, result.to_dict())
        return result


class ClientBase:
    """Transaction infrastructure shared by all client mixins."""

    def __init__(self, storage: StorageProtocol | str | Path = ".cascade"):
        if isinstance(storage, (str, Path)):
            self._storage: StorageProtocol = FileStorage(storage)
        else:
            self._storage = storage

    def _cached_op(self, op_id: str | None) -> Result | None:
        """Read a receipt inside the caller's existing mutation transaction."""
        if op_id is None:
            return None
        cached = self._storage.ops.get(op_id)
        if cached is not None:
            return Result.from_dict(cached)
        return None

    def _load_graph(self) -> Cascade:
        """Load graph under the storage lock; preserve and surface corruption."""
        graph = self._storage.load()
        if graph is None and self._storage.events.count:
            raise StorageCorruptionError(
                "snapshot is missing while the event log exists; restore a verified snapshot"
            )
        return graph if graph is not None else Cascade()

    def load(self) -> Cascade:
        """Load the current graph. Corrupt state raises without modifying evidence."""
        with self._storage.lock():
            return self._load_graph()

    @contextmanager
    def _mutate(self, op_id: str | None = None) -> Generator[_Tx, None, None]:
        """Transaction context: lock, load, yield _Tx."""
        with self._storage.lock():
            graph = self._load_graph()
            yield _Tx(graph, self._storage, op_id)

    def _expire_reservations(self, tx: _Tx, now: float, task_id: str | None = None) -> list[str]:
        """Release idle READY reservations using durable task activity evidence."""
        candidates = {
            node.id: node
            for node in tx.graph.nodes.values()
            if node.state == NodeState.READY
            and node.reserved_for is not None
            and (task_id is None or node.id == task_id)
        }
        if not candidates:
            return []
        activity = reservation_activity(self._storage.events.read_all())
        expired = []
        # Validate all candidates before emitting or changing any reservation.
        for node_id in candidates:
            last_activity = activity.get(node_id)
            if last_activity is None or not math.isfinite(last_activity.timestamp):
                raise StorageCorruptionError(
                    f"Cannot determine reservation age for {node_id}; restore its task history"
                )
            if (
                last_activity.type == EventType.TASK_TIMED_OUT
                or now - last_activity.timestamp >= 1800
            ):
                expired.append(node_id)
        for node_id in expired:
            node = candidates[node_id]
            event = activity[node_id]
            previous = node.reserved_for
            node.reserved_for = None
            tx.emit(
                EventType.NODE_EDITED,
                node_id=node_id,
                changes=["reservation expired"],
                reason="Execution lease expired"
                if event.type == EventType.TASK_TIMED_OUT
                else "Reservation inactive for 1800 seconds",
                reservation_expired={
                    "reserved_for": previous,
                    "activity_event_id": event.id,
                    "activity_at": event.timestamp,
                    "timeout_seconds": 1800,
                },
            )
        return expired

    @property
    def storage(self) -> StorageProtocol:
        return self._storage


# ---------------------------------------------------------------------------
# Module-private helpers
# ---------------------------------------------------------------------------


def _get_git_ref() -> str:
    """Get current HEAD commit hash, or empty string if not in a git repo."""
    try:
        r = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if r.returncode == 0:
            return r.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        pass
    return ""


def _update_context(
    node: Node,
    *,
    summary: str = "",
    critical: dict[str, Any] | None = None,
    artifacts: str = "",
    merge_mode: str = "merge",
) -> bool:
    """Update node context based on params. Returns True if context was updated."""
    if critical is None and not summary and not artifacts:
        return False

    if node.context is None:
        node.context = Context()

    ctx = node.context

    if merge_mode == "replace":
        if critical is not None:
            ctx.critical = dict(critical)
        if summary:
            ctx.summary = summary
        if artifacts:
            ctx.artifacts = str(artifacts)
    elif merge_mode == "append":
        if critical is not None:
            ctx.critical.update(critical)
        if summary:
            ctx.summary = (ctx.summary + "\n" + summary).strip()
        if artifacts:
            ctx.artifacts = str(artifacts)
    else:  # merge (default)
        if critical is not None:
            ctx.critical.update(critical)
        if summary:
            if ctx.summary:
                ctx.summary = ctx.summary + "\n" + summary
            else:
                ctx.summary = summary
        if artifacts:
            ctx.artifacts = str(artifacts)

    return True
