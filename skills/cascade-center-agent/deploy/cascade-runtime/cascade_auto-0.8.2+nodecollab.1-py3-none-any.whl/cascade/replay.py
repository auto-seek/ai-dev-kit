# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Event replay — rebuild graph state from the event log.

The event log is the source of truth. graph.json is a materialized
snapshot for fast access. This module can reconstruct the graph from
events alone, enabling:

- Disaster recovery (graph.json lost or corrupted)
- Distributed replication (follower replays leader's event stream)
- Consistency verification (replay == load)
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from cascade.core.cascade import Cascade
from cascade.core.node import Node
from cascade.core.state import NodeState
from cascade.errors import StorageCorruptionError
from cascade.events import Event, EventType, latest_task_failure, reservation_activity
from cascade.storage.content import ContentStore
from cascade.types import Context, Provenance


def replay(events: list[Event], content: ContentStore | None = None) -> Cascade:
    """Rebuild a Cascade graph by replaying events in order.

    Events must be sorted by logical_ts (or insertion order).
    If a ContentStore is provided, artifacts_ref values in events
    are resolved to content. Otherwise artifacts are left empty.
    """
    cascade = Cascade()

    for index, event in enumerate(events):
        if event.type == EventType.TASK_RETRIED:
            failure = latest_task_failure(events[:index], event.data.get("node_id", ""))
            if failure is None or failure.id != event.data.get("failure_event_id"):
                raise StorageCorruptionError(
                    "retry event does not match the current native failure"
                )
        if event.type == EventType.NODE_EDITED and "reservation_expired" in event.data:
            expiry = event.data["reservation_expired"]
            activity = reservation_activity(events[:index]).get(event.data.get("node_id", ""))
            if (
                not isinstance(expiry, dict)
                or activity is None
                or expiry.get("activity_event_id") != activity.id
                or expiry.get("activity_at") != activity.timestamp
                or expiry.get("timeout_seconds") != 1800
                or (
                    activity.type != EventType.TASK_TIMED_OUT
                    and event.timestamp - activity.timestamp < 1800
                )
            ):
                raise StorageCorruptionError("Reservation expiry has invalid activity evidence")
        _HANDLERS[event.type](cascade, event.data, content)
        if "epoch" in event.data:
            cascade.epoch = event.data["epoch"]

    return cascade


def verify(
    events: list[Event], snapshot: Cascade, content: ContentStore | None = None
) -> list[str]:
    """Compare replayed state against a snapshot. Returns list of differences."""
    replayed = replay(events, content)
    diffs: list[str] = []
    if replayed.epoch != snapshot.epoch:
        diffs.append(f"epoch {replayed.epoch} (replay) vs {snapshot.epoch} (snapshot)")

    replay_ids = set(replayed.nodes.keys())
    snap_ids = set(snapshot.nodes.keys())

    for nid in replay_ids - snap_ids:
        diffs.append(f"node {nid}: exists in replay but not in snapshot")
    for nid in snap_ids - replay_ids:
        diffs.append(f"node {nid}: exists in snapshot but not in replay")

    for nid in replay_ids & snap_ids:
        r_node = replayed.nodes[nid]
        s_node = snapshot.nodes[nid]
        for field in (
            "claim_token",
            "claimed_at",
            "timeout",
            "reserved_for",
            "task_input",
            "publication",
        ):
            if getattr(r_node, field) != getattr(s_node, field):
                diffs.append(
                    f"node {nid}: {field} {getattr(r_node, field)} (replay) vs {getattr(s_node, field)} (snapshot)"
                )
        if r_node.state != s_node.state:
            diffs.append(f"node {nid}: state {r_node.state} (replay) vs {s_node.state} (snapshot)")
        if r_node.agent_id != s_node.agent_id:
            diffs.append(
                f"node {nid}: agent {r_node.agent_id} (replay) vs {s_node.agent_id} (snapshot)"
            )
        if r_node.required_tier != s_node.required_tier:
            diffs.append(
                f"node {nid}: required_tier {r_node.required_tier} (replay) "
                f"vs {s_node.required_tier} (snapshot)"
            )
        if r_node.task_input is not None and r_node.context != s_node.context:
            diffs.append(f"node {nid}: versioned task delivery context differs from event replay")

    for edge_key in replayed.contracts:
        if edge_key not in snapshot.contracts:
            diffs.append(f"edge {edge_key}: exists in replay but not in snapshot")
    for edge_key in snapshot.contracts:
        if edge_key not in replayed.contracts:
            diffs.append(f"edge {edge_key}: exists in snapshot but not in replay")

    return diffs


# ---------------------------------------------------------------------------
# Per-event-type handlers
# ---------------------------------------------------------------------------


def _handle_node_added(
    cascade: Cascade, data: dict[str, Any], content: ContentStore | None
) -> None:
    node_id = data["node_id"]
    if node_id in cascade.nodes:
        return
    cascade.add_node(
        Node(
            id=node_id,
            required_tier=data.get("required_tier"),
            reserved_for=data.get("reserved_for"),
            task_input=data.get("task_input"),
            publication=data.get("publication"),
        )
    )

    for dep in data.get("deps_contracts", []):
        dep_id = dep["node_id"]
        if dep_id in cascade.nodes:
            cascade.add_edge(
                dep_id,
                node_id,
                expectation=dep["expectation"],
                promise=dep["promise"],
            )

    for dep in data.get("dependent_contracts", []):
        dep_id = dep["node_id"]
        if dep_id in cascade.nodes:
            cascade.add_edge(
                node_id,
                dep_id,
                expectation=dep["expectation"],
                promise=dep["promise"],
            )


def _handle_node_removed(
    cascade: Cascade, data: dict[str, Any], content: ContentStore | None
) -> None:
    for nid in data.get("affected_nodes", []):
        if nid in cascade.nodes and cascade.nodes[nid].state != NodeState.ACTIVE:
            cascade.remove_node(nid)


def _handle_node_split(
    cascade: Cascade, data: dict[str, Any], content: ContentStore | None
) -> None:
    required_tier = data.get("required_tier")
    for nid in data.get("new_node_ids", []):
        if nid not in cascade.nodes:
            cascade.add_node(
                Node(id=nid, required_tier=required_tier, reserved_for=data.get("reserved_for"))
            )
    parent_id = data.get("node_id", "")
    if parent_id in cascade.nodes and cascade.nodes[parent_id].state != NodeState.ACTIVE:
        cascade.remove_node(parent_id)


def _handle_node_refined(
    cascade: Cascade, data: dict[str, Any], content: ContentStore | None
) -> None:
    node_id = data.get("node_id", "")
    dep_id = data.get("dependency_id", "")
    if node_id in cascade.nodes and dep_id in cascade.nodes:
        cascade.add_edge(
            dep_id,
            node_id,
            expectation=data.get("expectation", ""),
            promise=data.get("promise", ""),
        )


def _handle_node_edited(
    cascade: Cascade, data: dict[str, Any], content: ContentStore | None
) -> None:
    node_id = data.get("node_id", "")
    if node_id not in cascade.nodes:
        return
    node = cascade.nodes[node_id]

    expiry = data.get("reservation_expired")
    if expiry is not None:
        if (
            not isinstance(expiry, dict)
            or not isinstance(expiry.get("reserved_for"), str)
            or not expiry["reserved_for"]
            or node.reserved_for != expiry["reserved_for"]
            or node.state != NodeState.READY
        ):
            raise StorageCorruptionError("Reservation expiry does not match a READY reservation")
        node.reserved_for = None

    new_state = data.get("new_state")
    if new_state and node.state.can_transition_to(NodeState[new_state]):
        node.update_state(NodeState[new_state])
        if NodeState[new_state] == NodeState.COMPLETED:
            cascade.notify_completion(node_id)

    ctx = data.get("context")
    if ctx:
        if node.context is None:
            node.context = Context()
        if "summary" in ctx:
            node.context.summary = ctx["summary"]
        if "critical" in ctx:
            node.context.critical.update(ctx["critical"])
        if "artifacts_ref" in ctx:
            ref = ctx["artifacts_ref"]
            node.context.artifacts = content.get(ref) or "" if content else ""


def _handle_task_claimed(
    cascade: Cascade, data: dict[str, Any], content: ContentStore | None
) -> None:
    node_id = data.get("node_id", "")
    if node_id not in cascade.nodes:
        return
    node = cascade.nodes[node_id]
    if node.state == NodeState.READY:
        node.update_state(NodeState.ACTIVE)
    token = data.get("claim_token")
    if not isinstance(token, int) or isinstance(token, bool) or token < 1:
        raise StorageCorruptionError(
            "claim event has no valid fencing token; pre-0.7 event logs cannot "
            "be replayed into executable state. Restore a verified full snapshot."
        )
    node.claim_token = token
    node.agent_id = data.get("agent_id")
    node.claimed_at = data.get("claimed_at")
    timeout = data.get("timeout")
    if timeout is not None:
        node.timeout = float(timeout)
    cascade.increment_epoch()


def _handle_task_completed(
    cascade: Cascade, data: dict[str, Any], content: ContentStore | None
) -> None:
    node_id = data.get("node_id", "")
    if node_id not in cascade.nodes:
        return
    node = cascade.nodes[node_id]
    if node.state == NodeState.ACTIVE:
        node.update_state(NodeState.COMPLETED)
    node.agent_id = None
    node.claimed_at = None
    node.timeout = None
    node.claim_token = None

    ctx = data.get("context")
    if ctx:
        if node.context is None:
            node.context = Context()
        if "summary" in ctx:
            node.context.summary = ctx["summary"]
        if "critical" in ctx:
            node.context.critical.update(ctx["critical"])
        if "artifacts_ref" in ctx:
            ref = ctx["artifacts_ref"]
            node.context.artifacts = content.get(ref) or "" if content else ""
        if "provenance" in ctx:
            node.context.provenance = Provenance.from_dict(ctx["provenance"])

    cascade.notify_completion(node_id)
    cascade.increment_epoch()


def _handle_task_failed(
    cascade: Cascade, data: dict[str, Any], content: ContentStore | None
) -> None:
    for nid in data.get("affected", [data.get("node_id", "")]):
        if nid in cascade.nodes:
            node = cascade.nodes[nid]
            if not node.state.is_terminal():
                node.update_state(NodeState.FAILED)
                node.agent_id = None
                node.claimed_at = None
                node.timeout = None
                node.claim_token = None
    cascade.increment_epoch()


def _handle_task_retried(
    cascade: Cascade, data: dict[str, Any], content: ContentStore | None
) -> None:
    for field in ("agent_id", "reason"):
        value = data.get(field)
        if not isinstance(value, str) or not value.strip():
            raise StorageCorruptionError(f"retry event requires nonempty text {field}")
    node_id = data.get("node_id", "")
    if node_id not in cascade.nodes or cascade.nodes[node_id].state != NodeState.FAILED:
        raise StorageCorruptionError("retry event requires an existing FAILED task")
    node = cascade.nodes[node_id]
    node.state = NodeState.PENDING
    node.agent_id = None
    node.claimed_at = None
    node.timeout = None
    node.claim_token = None
    cascade.recompute_readiness(node_id)
    if data.get("new_state") != node.state.name:
        raise StorageCorruptionError("retry event state disagrees with task dependencies")
    cascade.increment_epoch()


def _handle_task_released(
    cascade: Cascade, data: dict[str, Any], content: ContentStore | None
) -> None:
    node_id = data.get("node_id", "")
    if node_id not in cascade.nodes:
        return
    node = cascade.nodes[node_id]
    if node.state == NodeState.ACTIVE:
        node.update_state(NodeState.READY)
    node.agent_id = None
    node.claimed_at = None
    node.timeout = None
    node.claim_token = None
    cascade.increment_epoch()


def _handle_task_renewed(
    cascade: Cascade, data: dict[str, Any], content: ContentStore | None
) -> None:
    node_id = data.get("node_id", "")
    if node_id not in cascade.nodes:
        return
    node = cascade.nodes[node_id]
    renewed_at = data.get("renewed_at")
    if renewed_at is not None:
        node.claimed_at = float(renewed_at)
    timeout = data.get("timeout")
    if timeout is not None:
        node.timeout = float(timeout)


def _handle_task_timed_out(
    cascade: Cascade, data: dict[str, Any], content: ContentStore | None
) -> None:
    _handle_task_released(cascade, data, content)


def _handle_rework(cascade: Cascade, data: dict[str, Any], content: ContentStore | None) -> None:
    corrective_id = data.get("corrective_node_id", "")
    if corrective_id and corrective_id not in cascade.nodes:
        cascade.add_node(Node(id=corrective_id))

    source_id = data.get("source_node_id", "")
    if source_id in cascade.nodes and corrective_id in cascade.nodes:
        source_contract = data.get("source_contract")
        if source_contract:
            cascade.add_edge(
                source_id,
                corrective_id,
                expectation=source_contract.get("expectation", ""),
                promise=source_contract.get("promise", ""),
            )

    requesting_id = data.get("requesting_node_id", "")

    if requesting_id in cascade.nodes:
        node = cascade.nodes[requesting_id]
        if node.state == NodeState.ACTIVE:
            node.update_state(NodeState.READY)
            node.agent_id = None
            node.claimed_at = None
            node.timeout = None
            node.claim_token = None

    if requesting_id in cascade.nodes and corrective_id in cascade.nodes:
        corrective_contract = data.get("corrective_contract")
        if corrective_contract:
            cascade.add_edge(
                corrective_id,
                requesting_id,
                expectation=corrective_contract.get("expectation", ""),
                promise=corrective_contract.get("promise", ""),
            )


def _handle_node_cancelled(
    cascade: Cascade, data: dict[str, Any], content: ContentStore | None
) -> None:
    node_id = data.get("node_id", "")
    if node_id in cascade.nodes:
        node = cascade.nodes[node_id]
        if node.state.can_transition_to(NodeState.CANCELLED):
            node.update_state(NodeState.CANCELLED)


def _noop(cascade: Cascade, data: dict[str, Any], content: ContentStore | None) -> None:
    pass


_Handler = Callable[[Cascade, dict[str, Any], ContentStore | None], None]

_HANDLERS: dict[EventType, _Handler] = {
    EventType.NODE_ADDED: _handle_node_added,
    EventType.NODE_REMOVED: _handle_node_removed,
    EventType.NODE_SPLIT: _handle_node_split,
    EventType.NODE_REFINED: _handle_node_refined,
    EventType.NODE_EDITED: _handle_node_edited,
    EventType.EDGE_ADDED: _noop,
    EventType.EDGE_REMOVED: _noop,
    EventType.TASK_CLAIMED: _handle_task_claimed,
    EventType.TASK_COMPLETED: _handle_task_completed,
    EventType.TASK_FAILED: _handle_task_failed,
    EventType.TASK_RETRIED: _handle_task_retried,
    EventType.TASK_RELEASED: _handle_task_released,
    EventType.TASK_RENEWED: _handle_task_renewed,
    EventType.TASK_TIMED_OUT: _handle_task_timed_out,
    EventType.REWORK_REQUESTED: _handle_rework,
    EventType.NODE_CANCELLED: _handle_node_cancelled,
    EventType.GRAPH_CORRUPTED: _noop,
}
