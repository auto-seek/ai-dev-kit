# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Atomic distributed leases backed by a Git remote ref.

This is the first building block for a Redis-free ``GitStorage`` backend. A
lease update is accepted only when the remote ref still has the object id the
caller observed (Git's compare-and-swap / ``--force-with-lease`` semantics).
The class intentionally owns a dedicated bare cache and never checks
coordination refs into a product worktree.
"""

from __future__ import annotations

import json
import math
import os
import re
import socket
import subprocess
import time
import uuid
from collections.abc import Callable, Generator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from cascade.errors import LockContentionError, LockError

_SAFE_NAMESPACE = re.compile(r"^[A-Za-z0-9._-]+$")
_URI_USERINFO = re.compile(r"([A-Za-z][A-Za-z0-9+.-]*://)[^/@\s]+@")


def _redact_credentials(value: str) -> str:
    """Remove URI userinfo without discarding the actionable Git error."""
    return _URI_USERINFO.sub(r"\1<redacted>@", value)


def _validate_namespace(namespace: str) -> None:
    """Validate every Git ref shape before the namespace reaches a cache path."""
    if not _SAFE_NAMESPACE.fullmatch(namespace) or namespace in {".", ".."}:
        raise ValueError("namespace is not a valid Git ref component")
    refs = (
        f"refs/heads/cascade-state/{namespace}",
        f"refs/heads/cascade-lock/{namespace}",
        f"refs/heads/cascade-archive/{namespace}/0123456789ab",
        f"refs/cascade-cache/state/{namespace}",
        f"refs/cascade-cache/lock/{namespace}",
    )
    for ref in refs:
        try:
            result = subprocess.run(
                ["git", "check-ref-format", ref],
                capture_output=True,
                text=True,
                timeout=10,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise LockError(f"Git namespace validation could not complete: {exc}") from exc
        if result.returncode != 0:
            raise ValueError(f"namespace is not valid for Cascade Git refs: {namespace!r}")


class GitRefLease:
    """Short-lived distributed lock stored as a Git branch ref.

    Branch refs are used rather than a custom namespace because hosted Git
    services consistently allow fetch/push/delete for ``refs/heads/*``. A
    dedicated coordination remote is recommended so these refs do not clutter
    the product repository's branch list.
    """

    def __init__(
        self,
        remote: str,
        namespace: str,
        cache_dir: Path | str,
        *,
        holder_id: str | None = None,
        lease_seconds: float = 120.0,
        clock_skew_tolerance_seconds: float = 5.0,
        clock: Callable[[], float] = time.time,
    ) -> None:
        if not remote:
            raise ValueError("remote is required")
        _validate_namespace(namespace)
        if not math.isfinite(lease_seconds) or lease_seconds <= 0:
            raise ValueError("lease_seconds must be finite and positive")
        if not math.isfinite(clock_skew_tolerance_seconds) or clock_skew_tolerance_seconds < 0:
            raise ValueError("clock_skew_tolerance_seconds must be finite and non-negative")

        self.remote = remote
        self.namespace = namespace
        self.cache_dir = Path(cache_dir)
        self.holder_id = holder_id or (f"{socket.gethostname()}:{os.getpid()}:{uuid.uuid4().hex}")
        self.lease_seconds = lease_seconds
        self.clock_skew_tolerance_seconds = clock_skew_tolerance_seconds
        self._clock = clock
        self._held_oid: str | None = None
        self._lock_ref = f"refs/heads/cascade-lock/{namespace}"
        self._cache_ref = f"refs/cascade-cache/lock/{namespace}"
        self._ensure_cache()

    @property
    def lock_ref(self) -> str:
        """Remote ref used by this namespace."""
        return self._lock_ref

    @property
    def held(self) -> bool:
        return self._held_oid is not None

    def _ensure_cache(self) -> None:
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        if not (self.cache_dir / "HEAD").exists():
            self._run("init", "--bare", str(self.cache_dir), git_dir=False)

    def _run(
        self,
        *args: str,
        input_text: str | None = None,
        check: bool = True,
        git_dir: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        cmd = ["git"]
        if git_dir:
            cmd.extend(["--git-dir", str(self.cache_dir)])
        cmd.extend(args)
        env = os.environ.copy()
        env.setdefault("GIT_AUTHOR_NAME", "Cascade")
        env.setdefault("GIT_AUTHOR_EMAIL", "cascade@localhost")
        env.setdefault("GIT_COMMITTER_NAME", "Cascade")
        env.setdefault("GIT_COMMITTER_EMAIL", "cascade@localhost")
        failure: LockError | None = None
        result: subprocess.CompletedProcess[str] | None = None
        try:
            result = subprocess.run(
                cmd,
                input=input_text,
                capture_output=True,
                text=True,
                env=env,
                timeout=30,
            )
        except subprocess.TimeoutExpired:
            safe_cmd = _redact_credentials(" ".join(cmd))
            failure = LockError(f"Git lease command timed out: {safe_cmd}")
        except OSError as exc:
            safe_cmd = _redact_credentials(" ".join(cmd))
            detail = _redact_credentials(str(exc))
            failure = LockError(f"Git lease command could not start: {safe_cmd}: {detail}")
        if failure is not None:
            raise failure
        assert result is not None
        if check and result.returncode != 0:
            detail = _redact_credentials((result.stderr or result.stdout).strip())
            safe_cmd = _redact_credentials(" ".join(cmd))
            raise LockError(f"Git lease command failed: {safe_cmd}: {detail}")
        return result

    def _remote_oid(self) -> str | None:
        result = self._run("ls-remote", self.remote, self._lock_ref, git_dir=False)
        line = result.stdout.strip()
        return line.split()[0] if line else None

    def _fetch_payload(self, oid: str) -> dict[str, Any]:
        self._run(
            "fetch",
            "--quiet",
            "--no-tags",
            "--depth=1",
            self.remote,
            f"+{self._lock_ref}:{self._cache_ref}",
        )
        result = self._run("show", "-s", "--format=%B", self._cache_ref)
        try:
            payload = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise LockError(f"Git lease ref {self._lock_ref} has invalid metadata") from exc
        if not isinstance(payload, dict) or payload.get("namespace") != self.namespace:
            raise LockError(f"Git lease ref {self._lock_ref} has invalid namespace metadata")
        fetched_oid = self._run("rev-parse", self._cache_ref).stdout.strip()
        if fetched_oid != oid:
            raise LockError("Git lease changed while its metadata was being fetched")
        return payload

    def _new_commit(self, parent: str | None = None) -> str:
        tree = self._run("mktree", input_text="").stdout.strip()
        payload = json.dumps(
            {
                "holder": self.holder_id,
                "namespace": self.namespace,
                "expires_at": self._clock() + self.lease_seconds,
                "clock_skew_tolerance_seconds": self.clock_skew_tolerance_seconds,
            },
            sort_keys=True,
        )
        args = ["commit-tree", tree]
        if parent:
            args.extend(["-p", parent])
        return self._run(*args, input_text=payload).stdout.strip()

    def _push_cas(self, new_oid: str | None, expected_oid: str | None) -> bool:
        expected = expected_oid or ""
        source = new_oid or ""
        result = self._run(
            "push",
            "--porcelain",
            f"--force-with-lease={self._lock_ref}:{expected}",
            self.remote,
            f"{source}:{self._lock_ref}",
            check=False,
        )
        if result.returncode == 0:
            return True
        observed = self._remote_oid()
        if observed == new_oid:
            return True
        if observed != expected_oid:
            return False
        detail = _redact_credentials((result.stderr or result.stdout).strip())
        raise LockError(f"Git lease compare-and-swap command failed: {detail}")

    def acquire(
        self,
        *,
        timeout: float = 10.0,
        blocking: bool = True,
        poll_interval: float = 0.05,
    ) -> str:
        """Acquire or take over an expired lease and return its commit oid."""
        if self._held_oid is not None:
            raise LockError("Git lease is not re-entrant")
        deadline = time.monotonic() + max(timeout, 0.0)

        while True:
            current = self._remote_oid()
            now = self._clock()
            if current is not None:
                try:
                    payload = self._fetch_payload(current)
                except LockError:
                    if self._remote_oid() != current:
                        if not blocking:
                            raise LockContentionError(
                                f"Git lease {self._lock_ref} changed while acquisition was attempted"
                            ) from None
                        if time.monotonic() >= deadline:
                            raise LockContentionError(
                                f"Could not acquire Git lease {self._lock_ref} before timeout"
                            )
                        time.sleep(poll_interval)
                        continue
                    raise
                try:
                    expires_at = float(payload["expires_at"])
                    remote_tolerance = float(payload["clock_skew_tolerance_seconds"])
                except (KeyError, TypeError, ValueError) as exc:
                    raise LockError(
                        f"Git lease ref {self._lock_ref} has invalid expiry metadata"
                    ) from exc
                if (
                    not math.isfinite(expires_at)
                    or not math.isfinite(remote_tolerance)
                    or remote_tolerance < 0
                ):
                    raise LockError(f"Git lease ref {self._lock_ref} has invalid expiry metadata")
                safe_expiry = expires_at + max(self.clock_skew_tolerance_seconds, remote_tolerance)
                if safe_expiry > now:
                    remaining = deadline - time.monotonic()
                    if not blocking or remaining <= 0:
                        raise LockContentionError(
                            f"Git lease {self._lock_ref} is held by {payload.get('holder', '<unknown>')}"
                        )
                    time.sleep(min(poll_interval, remaining))
                    continue

            candidate = self._new_commit(parent=current)
            if self._push_cas(candidate, current):
                self._held_oid = candidate
                return candidate

            if not blocking or time.monotonic() >= deadline:
                raise LockContentionError(f"Could not acquire Git lease {self._lock_ref}")
            time.sleep(poll_interval)

    def renew(self) -> str:
        """Extend this holder's lease using CAS, refusing stale holders."""
        held = self._held_oid
        if held is None:
            raise LockError("Cannot renew a Git lease that is not held")
        if self._remote_oid() != held:
            self._held_oid = None
            raise LockError("Cannot renew Git lease: ownership changed")
        candidate = self._new_commit(parent=held)
        if not self._push_cas(candidate, held):
            self._held_oid = None
            raise LockError("Cannot renew Git lease: compare-and-swap rejected")
        self._held_oid = candidate
        return candidate

    def release(self) -> bool:
        """Release only this holder's ref; return false if ownership changed."""
        held = self._held_oid
        if held is None:
            return False
        released = self._push_cas(None, held)
        self._held_oid = None
        return released

    @contextmanager
    def lock(self, timeout: float = 10.0, blocking: bool = True) -> Generator[None, None, None]:
        self.acquire(timeout=timeout, blocking=blocking)
        try:
            yield
        finally:
            self.release()
