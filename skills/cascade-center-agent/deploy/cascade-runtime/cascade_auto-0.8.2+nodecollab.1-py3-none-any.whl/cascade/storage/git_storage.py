# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Git-backed Cascade storage for service-free cross-machine coordination.

Each transaction is materialized into a dedicated local cache, executed using
the proven file-backed subcomponents, then committed atomically to a remote
state ref while a :class:`GitRefLease` is held. Coordination data never enters
the caller's product worktree.
"""

from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import threading
import time
import uuid
from collections.abc import Callable, Generator
from contextlib import contextmanager
from pathlib import Path

from filelock import FileLock, Timeout

from cascade.core.cascade import Cascade
from cascade.errors import LockContentionError, LockError
from cascade.storage.content import ContentStore
from cascade.storage.file_storage import FileStorage
from cascade.storage.git_ref_lease import GitRefLease, _redact_credentials, _validate_namespace
from cascade.storage.protocol import EventStoreProtocol, OpLogProtocol, TokenStoreProtocol


class GitStorage:
    """StorageProtocol implementation backed by a Git remote.

    ``cache_dir`` must be local to one machine/container. Independent agents
    use independent caches and coordinate only through the remote refs.
    """

    def __init__(
        self,
        remote: str,
        *,
        namespace: str = "default",
        cache_dir: Path | str | None = None,
        lease_seconds: float = 120.0,
        clock_skew_tolerance_seconds: float = 5.0,
    ) -> None:
        if not remote:
            raise ValueError("remote is required")
        _validate_namespace(namespace)
        remote_key = hashlib.sha256(remote.encode("utf-8")).hexdigest()[:16]
        root = (
            Path(cache_dir)
            if cache_dir is not None
            else Path.home() / ".cache" / "cascade" / "git" / remote_key / namespace
        )
        self.remote = remote
        self.namespace = namespace
        self.cache_dir = root
        self._repo_dir = root / "state-repo"
        self._data_dir = self._repo_dir / "data"
        self._state_ref = f"refs/heads/cascade-state/{namespace}"
        self._cache_ref = f"refs/cascade-cache/state/{namespace}"
        self._base_oid: str | None = None
        self._cache_lock = FileLock(root / ".local-cache.lock")
        self._lease = GitRefLease(
            remote,
            namespace,
            root / "lease.git",
            holder_id=f"git-storage:{os.getpid()}:{uuid.uuid4().hex}",
            lease_seconds=lease_seconds,
            clock_skew_tolerance_seconds=clock_skew_tolerance_seconds,
        )
        self._renew_interval = lease_seconds / 3
        self._ensure_repo()
        self._file = FileStorage(self._data_dir)
        self.events: EventStoreProtocol = self._file.events
        self.tokens: TokenStoreProtocol = self._file.tokens
        self.ops: OpLogProtocol = self._file.ops
        self.content: ContentStore = self._file.content
        self._refresh_snapshot()

    @property
    def state_ref(self) -> str:
        return self._state_ref

    def _run(
        self,
        *args: str,
        input_text: str | None = None,
        check: bool = True,
        git_dir: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        cmd = ["git"]
        if git_dir:
            cmd.extend(["-C", str(self._repo_dir)])
        cmd.extend(args)
        env = os.environ.copy()
        env.setdefault("GIT_AUTHOR_NAME", "Cascade")
        env.setdefault("GIT_AUTHOR_EMAIL", "cascade@localhost")
        env.setdefault("GIT_COMMITTER_NAME", "Cascade")
        env.setdefault("GIT_COMMITTER_EMAIL", "cascade@localhost")
        failure: LockError | None = None
        result: subprocess.CompletedProcess[str] | None = None
        try:
            result = subprocess.run(
                cmd,
                input=input_text,
                capture_output=True,
                text=True,
                env=env,
                timeout=60,
            )
        except subprocess.TimeoutExpired:
            safe_cmd = _redact_credentials(" ".join(cmd))
            failure = LockError(f"Git storage command timed out: {safe_cmd}")
        except OSError as exc:
            safe_cmd = _redact_credentials(" ".join(cmd))
            detail = _redact_credentials(str(exc))
            failure = LockError(f"Git storage command could not start: {safe_cmd}: {detail}")
        if failure is not None:
            raise failure
        assert result is not None
        if check and result.returncode != 0:
            detail = _redact_credentials((result.stderr or result.stdout).strip())
            safe_cmd = _redact_credentials(" ".join(cmd))
            raise LockError(f"Git storage command failed: {safe_cmd}: {detail}")
        return result

    def _ensure_repo(self) -> None:
        self._repo_dir.mkdir(parents=True, exist_ok=True)
        if not (self._repo_dir / ".git").exists():
            self._run("init", "--quiet", str(self._repo_dir), git_dir=False)

    def _remote_state_oid(self) -> str | None:
        result = self._run("ls-remote", self.remote, self._state_ref, git_dir=False)
        line = result.stdout.strip()
        return line.split()[0] if line else None

    def _clear_worktree(self) -> None:
        for child in self._repo_dir.iterdir():
            if child.name == ".git":
                continue
            if child.is_dir() and not child.is_symlink():
                shutil.rmtree(child)
            else:
                child.unlink()

    def _bind_file_storage(self) -> None:
        self._file = FileStorage(self._data_dir)
        self.events = self._file.events
        self.tokens = self._file.tokens
        self.ops = self._file.ops
        self.content = self._file.content

    def _sync_state(self) -> None:
        """Materialize one complete remote snapshot into the local cache."""
        for _ in range(3):
            oid = self._remote_state_oid()
            self._clear_worktree()
            if oid is None:
                self._run("read-tree", "--empty")
                self._base_oid = None
                self._bind_file_storage()
                return
            self._run(
                "fetch",
                "--quiet",
                "--no-tags",
                "--depth=1",
                self.remote,
                f"+{self._state_ref}:{self._cache_ref}",
            )
            fetched = self._run("rev-parse", self._cache_ref).stdout.strip()
            if fetched != oid:
                continue
            self._run("read-tree", oid)
            self._run("checkout-index", "--all", "--force")
            self._base_oid = oid
            self._bind_file_storage()
            return
        raise LockError("Git state changed repeatedly while refreshing the local snapshot")

    def _refresh_snapshot(self) -> None:
        try:
            with self._cache_lock.acquire(timeout=10):
                self._sync_state()
        except Timeout as exc:
            raise LockContentionError("Could not acquire local Git storage cache lock") from exc

    def _publish_state(self) -> None:
        # Stage from the worktree root rather than naming ``data`` directly.
        # A read-only operation on a brand-new namespace may enter the storage
        # lock before FileStorage has created any data files. ``git add ...
        # data`` treats that absent pathspec as an error, whereas ``.`` is a
        # valid no-op and still stages a later deletion of the whole data tree.
        # ``--force`` prevents a user's global Git excludes (for example a
        # broad ``*.json`` rule) from silently dropping coordination files in
        # this isolated internal repository.
        self._run("add", "--all", "--force", "--", ".")
        tree = self._run("write-tree").stdout.strip()
        if self._base_oid:
            base_tree = self._run("rev-parse", f"{self._base_oid}^{{tree}}").stdout.strip()
        else:
            base_tree = self._run("mktree", input_text="").stdout.strip()
        if tree == base_tree:
            return

        args = ["commit-tree", tree]
        if self._base_oid:
            args.extend(["-p", self._base_oid])
        message = (
            f"cascade state {self.namespace}\n\n"
            f"holder={self._lease.holder_id}\n"
            f"created_at={time.time()}\n"
        )
        commit = self._run(*args, input_text=message).stdout.strip()
        self._push_ref_cas(commit, self._state_ref, self._base_oid)
        self._base_oid = commit

    @contextmanager
    def _maintain_lease(self) -> Generator[Callable[[], None], None, None]:
        """Renew the remote lease until the transaction and state push finish."""
        stop = threading.Event()
        failures: list[Exception] = []

        def renew_loop() -> None:
            while not stop.wait(self._renew_interval):
                try:
                    self._lease.renew()
                except Exception as exc:
                    failures.append(exc)
                    stop.set()

        def check() -> None:
            if failures:
                raise LockError(
                    f"Git transaction lease renewal failed: {failures[0]}"
                ) from failures[0]

        thread = threading.Thread(
            target=renew_loop,
            name=f"cascade-git-lease-{self.namespace}",
        )
        thread.start()
        primary: BaseException | None = None
        try:
            yield check
        except BaseException as exc:
            primary = exc
            raise
        finally:
            stop.set()
            thread.join()
            if primary is None:
                check()
            elif failures:
                primary.add_note(f"Git lease renewal also failed: {failures[0]}")

    def _remote_ref_oid(self, ref: str) -> str | None:
        result = self._run("ls-remote", self.remote, ref, git_dir=False)
        line = result.stdout.strip()
        return line.split()[0] if line else None

    def _push_ref_cas(self, source_oid: str, ref: str, expected_oid: str | None) -> None:
        result = self._run(
            "push",
            "--porcelain",
            f"--force-with-lease={ref}:{expected_oid or ''}",
            self.remote,
            f"{source_oid}:{ref}",
            check=False,
        )
        if result.returncode != 0:
            detail = _redact_credentials((result.stderr or result.stdout).strip())
            observed = self._remote_ref_oid(ref)
            if observed == source_oid:
                return
            if observed == expected_oid:
                raise LockError(f"Git ref compare-and-swap command failed for {ref}: {detail}")
            raise LockError(
                f"Git ref compare-and-swap rejected for {ref}: expected "
                f"{expected_oid or '<missing>'}, observed {observed or '<missing>'}: {detail}"
            )

    def _compact_state(self) -> str:
        """Archive the current tip and replace state history with one root snapshot."""
        old_oid = self._base_oid
        if old_oid is None:
            raise LockError("Cannot compact an unwritten Git namespace")
        archive_ref = f"refs/heads/cascade-archive/{self.namespace}/{old_oid[:12]}"
        archived_oid = self._remote_ref_oid(archive_ref)
        if archived_oid is None:
            self._push_ref_cas(old_oid, archive_ref, None)
        elif archived_oid != old_oid:
            raise LockError(f"Git archive ref {archive_ref} points to an unexpected commit")

        tree = self._run("write-tree").stdout.strip()
        message = (
            f"cascade compacted state {self.namespace}\n\n"
            f"archived_from={old_oid}\n"
            f"created_at={time.time()}\n"
        )
        compacted_oid = self._run("commit-tree", tree, input_text=message).stdout.strip()
        self._push_ref_cas(compacted_oid, self._state_ref, old_oid)
        self._base_oid = compacted_oid
        return archive_ref

    def compact(self) -> str:
        """Archive current history and publish an equivalent root snapshot."""
        archive_ref = ""
        with self.lock():
            archive_ref = self._compact_state()
        return archive_ref

    @contextmanager
    def lock(self, timeout: float = 10.0, blocking: bool = True) -> Generator[None, None, None]:
        local_timeout = timeout if blocking else 0
        try:
            with self._cache_lock.acquire(timeout=local_timeout):
                self._lease.acquire(timeout=timeout, blocking=blocking)
                primary: BaseException | None = None
                try:
                    with self._maintain_lease() as check_lease:
                        self._sync_state()
                        check_lease()
                        yield
                        check_lease()
                        self._publish_state()
                        check_lease()
                except BaseException as exc:
                    primary = exc
                    raise
                finally:
                    try:
                        released = self._lease.release()
                    except Exception as exc:
                        if primary is not None:
                            primary.add_note(f"Git transaction lease release also failed: {exc}")
                        else:
                            raise
                    else:
                        if not released:
                            release_error = LockError(
                                "Git transaction lease ownership was lost before release"
                            )
                            if primary is not None:
                                primary.add_note(str(release_error))
                            else:
                                raise release_error
        except Timeout as exc:
            raise LockContentionError("Could not acquire local Git storage cache lock") from exc

    def exists(self) -> bool:
        return self._file.exists()

    def next_lamport(self) -> int:
        return self._file.next_lamport()

    def observe(self, remote_ts: int) -> None:
        self._file.observe(remote_ts)

    def load(self) -> Cascade | None:
        return self._file.load()

    def save(self, cascade: Cascade) -> None:
        self._file.save(cascade)

    def backup_corrupt(self) -> str | None:
        return self._file.backup_corrupt()

    def delete(self) -> None:
        self._file.delete()
