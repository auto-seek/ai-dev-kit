# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Node implementation for DAG.

A Node is a pure data object — it knows its own identity, state, context,
and agent assignment, but nothing about the graph structure it lives in.
"""

import hashlib
import json
import math
from dataclasses import dataclass
from typing import Any

from cascade.core.state import NodeState
from cascade.errors import InvalidTransitionError
from cascade.types import Context, normalize_tier, validate_node_id


@dataclass
class Node:
    """A task node in the DAG.

    Fields:
        id: Unique identifier.
        state: Current lifecycle state.
        context: Optional context for information propagation.
        agent_id: ID of the agent currently working on this task, if any.
        claimed_at: Timestamp (time.time()) when the task was claimed (ACTIVE).
                    Set when entering ACTIVE, cleared when leaving ACTIVE.
        timeout: Optional timeout in seconds. If set, the task is considered
                 stalled after claimed_at + timeout and can be auto-released.
        claim_token: Fencing token for THIS claim of THIS node. Minted from the
                    graph's monotonic epoch on claim, checked for equality on
                    finish/renew, and cleared when leaving ACTIVE. Per-node (not
                    the graph-global epoch) so one agent's activity on another
                    node never invalidates this holder's token.
        required_tier: Optional portable capability floor (lite/pro/max).
                       Tier names map to concrete models outside Cascade.
        reserved_for: Optional agent with a 30-minute idle reservation.
                      None means the shared pool; split children inherit it.
                      Valid ACTIVE leases remain exclusive until released or expired.
    """

    id: str
    state: NodeState = NodeState.PENDING
    context: Context | None = None
    agent_id: str | None = None
    claimed_at: float | None = None
    timeout: float | None = None
    claim_token: int | None = None
    required_tier: str | None = None
    reserved_for: str | None = None
    task_input: dict[str, Any] | None = None
    publication: dict[str, Any] | None = None

    def __post_init__(self) -> None:
        validate_node_id(self.id)
        self.required_tier = normalize_tier(self.required_tier)
        if self.reserved_for is not None and (
            not isinstance(self.reserved_for, str) or not self.reserved_for.strip()
        ):
            raise ValueError("reserved_for must be a non-empty agent identifier or None")
        if self.task_input is not None:
            value = self.task_input
            if (
                not isinstance(value, dict)
                or set(value) != {"schema_version", "publication_id", "brief_sha256", "brief"}
                or type(value["schema_version"]) is not int
                or value["schema_version"] != 1
            ):
                raise ValueError("Invalid task input envelope")
            validate_node_id(value["publication_id"])
            brief = value["brief"]
            if not isinstance(brief, dict) or set(brief) != {
                "title",
                "goal",
                "context",
                "acceptance",
                "baseline",
                "requiredTier",
                "dependencies",
                "group",
            }:
                raise ValueError("Invalid task input fields")
            for key, limit in (
                ("title", 160),
                ("goal", 4000),
                ("context", 8000),
                ("acceptance", 4000),
                ("baseline", 300),
            ):
                entry = brief[key]
                if (
                    not isinstance(entry, str)
                    or not entry.strip()
                    or len(entry.encode("utf-16-le")) // 2 > limit
                ):
                    raise ValueError(f"Invalid task input {key}")
            if normalize_tier(brief["requiredTier"]) != self.required_tier:
                raise ValueError("Task input tier differs from node tier")
            dependencies = brief["dependencies"]
            if (
                not isinstance(dependencies, list)
                or len(dependencies) > 30
                or len(set(dependencies)) != len(dependencies)
            ):
                raise ValueError("Invalid task input dependencies")
            for dependency in dependencies:
                validate_node_id(dependency)
            if brief["group"] is not None and (
                not isinstance(brief["group"], str)
                or not brief["group"].strip()
                or len(brief["group"]) > 160
            ):
                raise ValueError("Invalid task input group")
            encoded = json.dumps(brief, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
            if hashlib.sha256(encoded.encode()).hexdigest() != value["brief_sha256"]:
                raise ValueError("Task input checksum differs")
            publication = self.publication
            if not isinstance(publication, dict) or set(publication) != {
                "publisher",
                "published_at",
                "protected_until",
            }:
                raise ValueError("Task input requires publication metadata")
            validate_node_id(publication["publisher"])
            for key in ("published_at", "protected_until"):
                if (
                    type(publication[key]) not in (int, float)
                    or not math.isfinite(publication[key])
                    or publication[key] < 0
                ):
                    raise ValueError("Invalid publication clock")
            if publication["protected_until"] != publication["published_at"] + 300:
                raise ValueError("Publication protection must be exactly 300 seconds")
            self.task_input = json.loads(json.dumps(value))
            self.publication = dict(publication)
        elif self.publication is not None:
            raise ValueError("Publication metadata requires task input")

    def update_state(self, new_state: NodeState) -> "Node":
        """Transition to a new state.

        Raises:
            ValueError: If the transition is invalid per NodeState rules.

        Returns:
            Self for method chaining.
        """
        if not self.state.can_transition_to(new_state):
            raise InvalidTransitionError(f"Invalid state transition: {self.state} -> {new_state}")
        self.state = new_state
        return self

    def is_timed_out(self, now: float) -> bool:
        """Check if this node has exceeded its timeout.

        Only meaningful for ACTIVE nodes with both claimed_at and timeout set.
        """
        if self.state != NodeState.ACTIVE:
            return False
        if self.claimed_at is None or self.timeout is None:
            return False
        return now - self.claimed_at >= self.timeout

    def __repr__(self) -> str:
        parts = [f"id={self.id!r}", f"state={self.state}"]
        if self.agent_id:
            parts.append(f"agent={self.agent_id!r}")
        if self.required_tier:
            parts.append(f"required_tier={self.required_tier!r}")
        return f"Node({', '.join(parts)})"
