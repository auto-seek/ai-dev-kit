# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Archives Tool — query archived cascade instances."""

from typing import Any

from cascade.storage.protocol import StorageProtocol


def archives(storage: StorageProtocol, params: dict[str, Any]) -> dict[str, Any]:
    """Query archived cascade instances.

    Args:
        storage: StorageProtocol instance
        params: Dictionary containing:
            - archive_id (str, optional): Get details of a specific archive
            - workspace_path (str, optional): Filter by workspace path
            - all (bool, optional): Show all archives across workspaces
    """
    from cascade.archive import get_archive, list_archives
    from cascade.storage.file_storage import FileStorage

    archive_id = params.get("archive_id")
    if archive_id:
        r = get_archive(archive_id)
        return r.to_dict()

    workspace_path = params.get("workspace_path")
    if workspace_path is None and not params.get("all", False):
        if isinstance(storage, FileStorage):
            workspace_path = str(storage.base_dir.resolve().parent)

    r = list_archives(workspace_path=workspace_path)
    return r.to_dict()
