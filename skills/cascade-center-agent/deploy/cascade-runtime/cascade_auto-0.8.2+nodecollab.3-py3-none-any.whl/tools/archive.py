# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Archive Tool — snapshot current cascade to global archive."""

from typing import Any

from cascade.storage.protocol import StorageProtocol


def archive(storage: StorageProtocol, params: dict[str, Any]) -> dict[str, Any]:
    """Snapshot current cascade state to ~/.cascade/archives/.

    Args:
        storage: StorageProtocol instance
        params: Dictionary containing:
            - description (str, optional): Archive description
    """
    from cascade.archive import archive as do_archive
    from cascade.storage.file_storage import FileStorage

    if isinstance(storage, FileStorage):
        source_dir = str(storage.base_dir)
    else:
        source_dir = params.get("source_dir", ".cascade")

    r = do_archive(source_dir, description=params.get("description", ""))
    return r.to_dict()
