# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Retry Task Tool — thin wrapper delegating to CascadeClient."""

from typing import Any

from cascade.client import CascadeClient
from cascade.storage.protocol import StorageProtocol


def retry_task(storage: StorageProtocol, params: dict[str, Any]) -> dict[str, Any]:
    """Reopen a failed task using task_id, failure_event_id, agent_id and reason.

    Optional op_id identifies this exact request. Success does not claim the
    task; already_applied marks a historical result rather than current state.
    """
    return (
        CascadeClient(storage)
        .retry(
            params.get("task_id", ""),
            failure_event_id=params.get("failure_event_id", ""),
            agent_id=params.get("agent_id", ""),
            reason=params.get("reason", ""),
            op_id=params.get("op_id"),
        )
        .to_dict()
    )
