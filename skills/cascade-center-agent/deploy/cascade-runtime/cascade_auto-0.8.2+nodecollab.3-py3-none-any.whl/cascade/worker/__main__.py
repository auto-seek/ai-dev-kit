# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
# SPDX-License-Identifier: Apache-2.0

"""Run a coordinator-approved dispatch: python -m cascade.worker --config FILE."""

from __future__ import annotations

import argparse
import json
import signal
import threading
from pathlib import Path

from cascade.worker import WorkerConfig, WorkerError, run_worker


def main() -> int:
    parser = argparse.ArgumentParser(description="Execute one supervised Cascade harness dispatch")
    parser.add_argument(
        "--config", type=Path, required=True, help="Trusted dispatch JSON; no embedded secrets"
    )
    args = parser.parse_args()
    cancelled = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: cancelled.set())
    signal.signal(signal.SIGINT, lambda *_: cancelled.set())
    try:
        document = json.loads(args.config.read_text(encoding="utf-8"))
    except (ValueError, OSError) as exc:
        print(
            json.dumps(
                {"status": "failed", "error": f"cannot read dispatch JSON ({type(exc).__name__})"}
            )
        )
        return 1
    try:
        config = WorkerConfig.from_dict(document)
        report = run_worker(config, cancelled=cancelled)
    except (ValueError, WorkerError) as exc:
        # These are our own field/contract validation messages, with no supplied
        # field values; the operator needs to know which configuration to repair.
        print(json.dumps({"status": "failed", "error": str(exc)}))
        return 1
    except OSError as exc:
        print(
            json.dumps(
                {"status": "failed", "error": f"dispatch setup failed ({type(exc).__name__})"}
            )
        )
        return 1
    print(json.dumps(report, ensure_ascii=False))
    return 0 if report["status"] == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
