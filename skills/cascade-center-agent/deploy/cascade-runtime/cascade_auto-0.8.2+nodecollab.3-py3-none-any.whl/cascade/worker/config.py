# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
# SPDX-License-Identifier: Apache-2.0

"""Trusted dispatch configuration. Secrets belong in the execution environment."""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from cascade.types import normalize_tier


def _object(value: Any, name: str, keys: set[str]) -> dict[str, Any]:
    if not isinstance(value, dict) or not set(value) <= keys:
        raise ValueError(f"{name} must be an object with only these fields: {sorted(keys)}")
    return value


def _text(value: Any, name: str) -> str:
    if not isinstance(value, str) or not value.strip() or "\x00" in value:
        raise ValueError(f"{name} must be a nonempty string without NUL")
    return value


def _argv(value: Any, name: str) -> tuple[str, ...]:
    if not isinstance(value, list) or not value:
        raise ValueError(f"{name} must be a nonempty argv array")
    return tuple(_text(item, name) for item in value)


def _seconds(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a positive finite number")
    number = float(value)
    if not math.isfinite(number) or number <= 0:
        raise ValueError(f"{name} must be a positive finite number")
    return number


def _remote(value: Any, name: str) -> str:
    remote = _text(value, name)
    if remote.startswith("-") or "\n" in remote or "\r" in remote:
        raise ValueError(f"{name} is not a valid Git remote")
    parsed = urlsplit(remote)
    if parsed.password is not None or (
        parsed.scheme in {"http", "https"} and parsed.username is not None
    ):
        raise ValueError(f"{name} must not contain embedded credentials")
    return remote


@dataclass(frozen=True)
class WorkerConfig:
    """A coordinator-approved single-task execution contract."""

    git_remote: str
    namespace: str
    cache_dir: Path
    task_id: str
    prompt: str
    allowed_paths: tuple[str, ...]
    validation_commands: tuple[tuple[str, ...], ...]
    preflight_command: tuple[str, ...]
    timeout_seconds: float
    repository_remote: str
    base_ref: str
    base_branch: str
    bootstrap_commands: tuple[tuple[str, ...], ...]
    harness_command: tuple[str, ...]
    auth_command: tuple[str, ...]
    version_command: tuple[str, ...]
    auth_json_equals: dict[str, Any] | None
    pass_env: tuple[str, ...]
    agent_id: str
    agent_tier: str
    workspace_root: Path
    lease_seconds: float
    renew_interval_seconds: float
    publication_remote: str
    branch_prefix: str

    @classmethod
    def from_dict(cls, document: dict[str, Any]) -> WorkerConfig:
        root = _object(
            document,
            "config",
            {"coordination", "task", "repository", "harness", "worker", "publication"},
        )
        coord = _object(
            root.get("coordination"), "coordination", {"git_remote", "namespace", "cache_dir"}
        )
        task = _object(
            root.get("task"),
            "task",
            {
                "id",
                "prompt",
                "allowed_paths",
                "validation_commands",
                "preflight_command",
                "timeout_seconds",
            },
        )
        repo = _object(
            root.get("repository"),
            "repository",
            {"remote", "base_ref", "base_branch", "bootstrap_commands"},
        )
        harness = _object(
            root.get("harness"),
            "harness",
            {"command", "auth_command", "version_command", "auth_json_equals", "pass_env"},
        )
        worker = _object(
            root.get("worker"),
            "worker",
            {"agent_id", "agent_tier", "workspace_root", "lease_seconds", "renew_interval_seconds"},
        )
        publication = _object(root.get("publication"), "publication", {"remote", "branch_prefix"})
        base_ref = _text(repo.get("base_ref"), "repository.base_ref")
        if not re.fullmatch(r"[a-fA-F0-9]{40}|[a-fA-F0-9]{64}", base_ref):
            raise ValueError("repository.base_ref must be a full immutable Git commit ID")
        task_id = _text(task.get("id"), "task.id")
        if not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_-]*", task_id):
            raise ValueError("task.id must be a canonical task slug without lane or path suffixes")
        base_branch = _text(repo.get("base_branch", "main"), "repository.base_branch")
        if not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_/-]*", base_branch):
            raise ValueError("repository.base_branch must be a valid review target branch")
        if base_branch == f"codex/{task_id}" or base_branch.endswith("/") or "//" in base_branch:
            raise ValueError(
                "repository.base_branch must be distinct from the canonical task branch"
            )
        bootstrap = repo.get("bootstrap_commands", [])
        if not isinstance(bootstrap, list):
            raise ValueError("repository.bootstrap_commands must be an array of argv arrays")
        allowed = _argv(task.get("allowed_paths"), "task.allowed_paths")
        if any(path.startswith("/") or ".." in path.split("/") for path in allowed):
            raise ValueError("task.allowed_paths must be repository-relative patterns without '..'")
        commands = task.get("validation_commands")
        if not isinstance(commands, list) or not commands:
            raise ValueError("task.validation_commands must contain at least one command")
        tier = normalize_tier(_text(worker.get("agent_tier"), "worker.agent_tier"))
        assert tier is not None
        lease = _seconds(worker.get("lease_seconds", 300), "worker.lease_seconds")
        interval = _seconds(
            worker.get("renew_interval_seconds", 30), "worker.renew_interval_seconds"
        )
        if interval > lease / 3:
            raise ValueError("renew_interval_seconds must be at most one third of lease_seconds")
        prefix = _text(
            publication.get("branch_prefix", "codex/worker"), "publication.branch_prefix"
        )
        if not re.fullmatch(r"codex/[a-zA-Z0-9_-]+(?:/[a-zA-Z0-9_-]+)*", prefix):
            raise ValueError("publication.branch_prefix must be a valid branch prefix below codex/")
        auth_expected = harness.get("auth_json_equals")
        if auth_expected is not None and (not isinstance(auth_expected, dict) or not auth_expected):
            raise ValueError("harness.auth_json_equals must be a nonempty object when supplied")
        pass_env = harness.get("pass_env", [])
        if not isinstance(pass_env, list) or any(
            not isinstance(name, str) or not re.fullmatch(r"[A-Z_][A-Z0-9_]*", name)
            for name in pass_env
        ):
            raise ValueError("harness.pass_env must contain environment variable names")
        return cls(
            git_remote=_remote(coord.get("git_remote"), "coordination.git_remote"),
            namespace=_text(coord.get("namespace"), "coordination.namespace"),
            cache_dir=Path(_text(coord.get("cache_dir"), "coordination.cache_dir"))
            .expanduser()
            .resolve(),
            task_id=task_id,
            prompt=_text(task.get("prompt"), "task.prompt"),
            allowed_paths=allowed,
            validation_commands=tuple(_argv(command, "validation command") for command in commands),
            preflight_command=_argv(task.get("preflight_command"), "task.preflight_command"),
            timeout_seconds=_seconds(task.get("timeout_seconds"), "task.timeout_seconds"),
            repository_remote=_remote(repo.get("remote"), "repository.remote"),
            base_ref=base_ref.lower(),
            base_branch=base_branch,
            bootstrap_commands=tuple(_argv(command, "bootstrap command") for command in bootstrap),
            harness_command=_argv(harness.get("command"), "harness.command"),
            auth_command=_argv(harness.get("auth_command"), "harness.auth_command"),
            version_command=_argv(harness.get("version_command"), "harness.version_command"),
            auth_json_equals=auth_expected,
            pass_env=tuple(pass_env),
            agent_id=_text(worker.get("agent_id"), "worker.agent_id"),
            agent_tier=tier,
            workspace_root=Path(_text(worker.get("workspace_root"), "worker.workspace_root"))
            .expanduser()
            .resolve(),
            lease_seconds=lease,
            renew_interval_seconds=interval,
            publication_remote=_remote(publication.get("remote"), "publication.remote"),
            branch_prefix=prefix,
        )
