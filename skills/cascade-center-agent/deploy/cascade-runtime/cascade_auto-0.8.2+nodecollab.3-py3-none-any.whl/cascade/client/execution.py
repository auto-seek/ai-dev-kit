# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Client mixin — task execution lifecycle and failure-bound operator retry."""

from __future__ import annotations

import time
from typing import Any

from cascade import tips
from cascade.client.base import ClientBase, _get_git_ref, _Tx
from cascade.core.node import Node
from cascade.core.state import NodeState
from cascade.errors import LockContentionError, LockError, StateConflictError
from cascade.events import EventType, latest_task_failure
from cascade.storage.token_store import CancelNotifier
from cascade.types import (
    CAPABILITY_TIERS,
    Context,
    ErrorCode,
    Provenance,
    Result,
    normalize_tier,
    tier_satisfies,
    validate_node_id,
)
from cascade.view import get_node_view


def _stale_token_result(provided: int, expected: int | None) -> Result:
    """Fencing rejection: the provided token is not this claim's token.

    Per-node fencing — the token is compared against the node's own claim_token,
    not a graph-global epoch, so another agent's activity elsewhere never makes
    this token stale. A mismatch means the task was released/timed-out and
    re-claimed (a newer token exists), or the caller never held this claim.
    """
    return Result(
        success=False,
        message=(
            f"Stale fencing token: provided {provided}, this claim's token is "
            f"{expected}. The task was re-claimed since this token was issued, "
            f"or this token was never valid for this task."
        ),
        data={"provided_token": provided, "expected_token": expected},
        code=ErrorCode.STALE_TOKEN,
    )


_RENEW_ATTEMPTS = 4


class ExecutionMixin(ClientBase):
    """Task execution lifecycle: claim, complete, fail, release."""

    def _release_if_timed_out(self, tx: _Tx, node: Node, now: float) -> bool:
        """Release one expired ACTIVE claim inside the caller's transaction.

        Expiry counts the claim's current heartbeat. The commit also removes
        that heartbeat expecting the OID read here, so a renewal that lands
        first makes this transaction redo instead of reclaiming a live claim.
        """
        heartbeat = tx.heartbeat(node)
        if not node.is_timed_out(now, heartbeat):
            return False

        old_agent = node.agent_id
        elapsed = now - (node.lease_renewed_at(heartbeat) or now)
        node.update_state(NodeState.READY)
        node.agent_id = None
        node.claimed_at = None
        node.timeout = None
        node.claim_token = None
        self._storage.tokens.invalidate(node.id, reason="timed_out")
        tx.emit(
            EventType.TASK_TIMED_OUT,
            node_id=node.id,
            agent_id=old_agent,
            elapsed=round(elapsed, 1),
        )
        return True

    def claim(
        self,
        agent_id: str,
        task_id: str | None = None,
        *,
        agent_tier: str | None = None,
        timeout: float | None = None,
        cancel_notifier: CancelNotifier | None = None,
    ) -> Result:
        """Claim a task to work on.

        Args:
            agent_id: Unique agent identifier.
            task_id: Specific task to claim (or None for highest-priority READY).
            agent_tier: Declared portable capability tier (lite/pro/max).
            timeout: Auto-release after this many seconds.
            cancel_notifier: Push notification on cancellation.
        """
        if not agent_id:
            return Result(
                success=False,
                message="agent_id is required. Each agent can only hold ONE task at a time.",
                code=ErrorCode.MISSING_AGENT_ID,
            )

        try:
            normalized_agent_tier = normalize_tier(agent_tier)
        except ValueError as e:
            return Result(success=False, message=str(e), code=ErrorCode.INVALID_INPUT)

        backoffs = [0.1, 0.4, 1.6]
        for attempt in range(len(backoffs) + 1):
            try:
                return self._claim_locked(
                    agent_id,
                    task_id,
                    agent_tier=normalized_agent_tier,
                    timeout=timeout,
                    cancel_notifier=cancel_notifier,
                )
            except LockContentionError:
                if attempt < len(backoffs):
                    time.sleep(backoffs[attempt])
                    continue
                return Result(
                    success=False,
                    message=(
                        f"Could not acquire lock after {len(backoffs) + 1} attempts. "
                        "Another agent may be holding it for an extended period."
                    ),
                    code=ErrorCode.LOCK_CONTENTION,
                )
            except Exception as e:
                return Result(
                    success=False, message=f"Operation failed: {e}", code=ErrorCode.INTERNAL_ERROR
                )

        return Result(
            success=False, message="claim retry exhausted", code=ErrorCode.LOCK_CONTENTION
        )

    def _claim_locked(
        self,
        agent_id: str,
        task_id: str | None,
        *,
        agent_tier: str | None,
        timeout: float | None,
        cancel_notifier: CancelNotifier | None,
    ) -> Result:
        """Single-attempt claim — raises LockContentionError on contention."""

        def body(tx: _Tx) -> Result:
            # Each attempt chooses again: an earlier attempt's choice may be taken.
            claim_id = task_id
            graph = tx.graph

            # A claim is the natural liveness heartbeat. Reclaim expired work
            # in the same lock/transaction so crashed agents cannot leave the
            # queue blocked until a separate check-timeouts process runs.
            now = time.time()
            if self._expire_reservations(tx, now, claim_id):
                tx.save()
            released_timed_out = False
            if claim_id is not None and claim_id in graph.nodes:
                released_timed_out = self._release_if_timed_out(tx, graph.nodes[claim_id], now)
            elif claim_id is None:
                for candidate in graph.nodes.values():
                    released_timed_out = (
                        self._release_if_timed_out(tx, candidate, now) or released_timed_out
                    )
            if released_timed_out:
                self._expire_reservations(tx, now, claim_id)
                tx.save()

            existing_node = graph.find_agent_active_task(agent_id)
            if existing_node:
                return Result(
                    success=False,
                    message=(
                        f"Agent {agent_id} already holds active task "
                        f"'{existing_node.id}'. Finish it before claiming a new one."
                    ),
                    data={
                        "current_task": existing_node.id,
                        "state": "ACTIVE",
                    },
                    code=ErrorCode.ALREADY_HAS_ACTIVE,
                )

            if claim_id:
                if claim_id not in graph.nodes:
                    return Result(
                        success=False,
                        message=f"Task {claim_id} not found",
                        code=ErrorCode.TASK_NOT_FOUND,
                    )

                node = graph.nodes[claim_id]

                if (
                    node.publication is not None
                    and node.state != NodeState.ACTIVE
                    and now < node.publication["protected_until"]
                    and node.publication["publisher"] != agent_id
                ):
                    return Result(
                        success=False,
                        message="Task is in its publisher's five-minute claim window",
                        data={
                            "task_id": claim_id,
                            "protected_until": node.publication["protected_until"],
                        },
                        code=ErrorCode.TASK_RESERVED,
                    )

                if node.reserved_for is not None and node.reserved_for != agent_id:
                    return Result(
                        success=False,
                        message=f"Task {claim_id} is reserved for agent '{node.reserved_for}', not '{agent_id}'.",
                        data={"task_id": claim_id, "reserved_for": node.reserved_for},
                        code=ErrorCode.TASK_RESERVED,
                    )

                if node.agent_id and node.agent_id != agent_id and node.state == NodeState.ACTIVE:
                    return Result(
                        success=False,
                        message=f"Task {claim_id} is already being executed by agent: {node.agent_id}",
                        data={"state": "ACTIVE", "assigned_to": node.agent_id},
                        code=ErrorCode.TASK_ALREADY_ACTIVE,
                    )

                if node.state == NodeState.ACTIVE:
                    node.agent_id = agent_id
                    task_info = get_node_view(graph, claim_id)
                    tx.save()
                    return Result(
                        success=True,
                        message=f"Task {claim_id} is already active",
                        data={"task_id": claim_id, "state": "ACTIVE", "task_info": task_info},
                    )

                if node.state.is_terminal():
                    return Result(
                        success=False,
                        message=f"Task {claim_id} is in terminal state: {node.state.name}",
                        data={"state": node.state.name},
                        code=ErrorCode.TASK_TERMINAL,
                    )

                if node.state == NodeState.PENDING:
                    pending = graph.pending_dependency_count(claim_id)
                    return Result(
                        success=False,
                        message=f"Task {claim_id} is not ready (dependencies not met, pending={pending})",
                        data={"state": "PENDING", "pending_dependencies": pending},
                        code=ErrorCode.TASK_NOT_READY,
                    )

                if not tier_satisfies(agent_tier, node.required_tier):
                    declared = agent_tier or "unspecified"
                    return Result(
                        success=False,
                        message=(
                            f"Task {claim_id} requires tier '{node.required_tier}', but agent "
                            f"{agent_id} declared '{declared}'. Use an eligible agent; only "
                            "declare a higher tier when the harness maps it to a capable model."
                        ),
                        data={
                            "task_id": claim_id,
                            "required_tier": node.required_tier,
                            "agent_tier": agent_tier,
                        },
                        code=ErrorCode.INSUFFICIENT_TIER,
                    )

                node.update_state(NodeState.ACTIVE)
                node.agent_id = agent_id
                node.claimed_at = time.time()
                if timeout is not None:
                    node.timeout = float(timeout)

            else:
                all_ready_nodes = [
                    candidate
                    for candidate in graph.get_ready_nodes()
                    if candidate.reserved_for is None or candidate.reserved_for == agent_id
                    if candidate.publication is None
                    or now >= candidate.publication["protected_until"]
                    or candidate.publication["publisher"] == agent_id
                ]
                ready_nodes = [
                    candidate
                    for candidate in all_ready_nodes
                    if tier_satisfies(agent_tier, candidate.required_tier)
                ]

                if not ready_nodes:
                    if all_ready_nodes:
                        present_tiers = {
                            n.required_tier for n in all_ready_nodes if n.required_tier
                        }
                        required = [tier for tier in CAPABILITY_TIERS if tier in present_tiers]
                        declared = agent_tier or "unspecified"
                        return Result(
                            success=False,
                            message=(
                                f"No READY tasks match agent tier '{declared}'. "
                                f"Available tasks require: {', '.join(required)}."
                            ),
                            data={
                                "agent_tier": agent_tier,
                                "required_tiers": required,
                                "eligible": 0,
                            },
                            code=ErrorCode.INSUFFICIENT_TIER,
                        )
                    active_count = sum(
                        1 for n in graph.nodes.values() if n.state == NodeState.ACTIVE
                    )
                    pending_count = sum(
                        1 for n in graph.nodes.values() if n.state == NodeState.PENDING
                    )

                    if active_count > 0:
                        return Result(
                            success=False,
                            message=f"No available tasks. {active_count} task(s) are executed, {pending_count} pending.",
                            data={"active": active_count, "pending": pending_count},
                            code=ErrorCode.NO_READY_TASKS,
                        )
                    else:
                        return Result(
                            success=False,
                            message=f"No available tasks. All {pending_count} tasks are pending (dependencies not met).",
                            data={"pending": pending_count},
                            code=ErrorCode.NO_READY_TASKS,
                        )

                node = ready_nodes[0]
                claim_id = node.id
                node.update_state(NodeState.ACTIVE)
                node.agent_id = agent_id
                node.claimed_at = time.time()
                if timeout is not None:
                    node.timeout = float(timeout)

            if node.task_input is not None:
                if timeout is not None and (
                    type(timeout) not in (int, float) or not 1 <= timeout <= 86400
                ):
                    return Result(
                        success=False,
                        message="Lease must be between 1 and 86400 seconds",
                        code=ErrorCode.INVALID_INPUT,
                    )
                if node.timeout is None:
                    node.timeout = 900.0
            token = graph.increment_epoch()
            node.claim_token = token
            task_info = get_node_view(graph, claim_id)
            if agent_tier is not None:
                task_info["agent_tier"] = agent_tier
            self._storage.tokens.create(
                claim_id, agent_id, node.claimed_at, notifier=cancel_notifier
            )
            tx.emit(
                EventType.TASK_CLAIMED,
                node_id=claim_id,
                agent_id=agent_id,
                claimed_at=node.claimed_at,
                timeout=node.timeout,
                agent_tier=agent_tier,
                claim_token=token,
                **(
                    {
                        "input_receipt": {
                            "brief_sha256": node.task_input["brief_sha256"],
                            "upstream": task_info.get("upstream", []),
                        }
                    }
                    if node.task_input is not None
                    else {}
                ),
            )
            tx.save()

            released_events = self._storage.events.read_by_node(claim_id)
            was_released = any(e.type == EventType.TASK_RELEASED for e in released_events)

            claim_tips = tips.on_claim(
                task_id=claim_id,
                upstream=task_info.get("upstream", []),
                promises=task_info.get("promises", []),
                was_previously_released=was_released,
            )

            return Result(
                success=True,
                message=tips.append_tips(f"Task {claim_id} assigned (state: ACTIVE)", claim_tips),
                data={
                    "task_id": claim_id,
                    "state": "ACTIVE",
                    "task_info": task_info,
                    "assigned_to": agent_id,
                    "agent_tier": agent_tier,
                    "token": token,
                },
            )

        return self._transact(body)

    def complete(
        self,
        task_id: str,
        *,
        agent_id: str | None = None,
        token: int | None = None,
        op_id: str | None = None,
        summary: str = "",
        critical: dict[str, Any] | None = None,
        artifacts: str = "",
        deliverables: dict[str, str] | None = None,
    ) -> Result:
        """Mark a task as successfully completed."""
        return self._finish(
            task_id,
            agent_id=agent_id,
            token=token,
            op_id=op_id,
            is_success=True,
            is_release=False,
            summary=summary,
            critical=critical,
            artifacts=artifacts,
            deliverables=deliverables,
        )

    def fail(
        self,
        task_id: str,
        *,
        agent_id: str | None = None,
        token: int | None = None,
        op_id: str | None = None,
        reason: str = "",
        cascade: bool = False,
    ) -> Result:
        """Mark a task as failed."""
        return self._finish(
            task_id,
            agent_id=agent_id,
            token=token,
            op_id=op_id,
            is_success=False,
            is_release=False,
            summary=reason,
            should_cascade=cascade,
        )

    def release(
        self,
        task_id: str,
        *,
        agent_id: str | None = None,
        token: int | None = None,
        op_id: str | None = None,
        reason: str = "",
    ) -> Result:
        """Release a task back to READY."""
        return self._finish(
            task_id,
            agent_id=agent_id,
            token=token,
            op_id=op_id,
            is_success=False,
            is_release=True,
            summary=reason,
        )

    def retry(
        self,
        task_id: str,
        *,
        failure_event_id: str,
        reason: str,
        agent_id: str,
        op_id: str | None = None,
    ) -> Result:
        """Authorize another attempt of the exact native failure, without claiming it.

        The operator identity is an audit field, not authentication. Reusing an
        op_id with the same request returns a historical receipt marked
        already_applied; its state is not a fresh ownership observation.
        """
        try:
            validate_node_id(task_id)
        except ValueError as error:
            return Result(success=False, message=str(error), code=ErrorCode.INVALID_INPUT)
        for name, value in (
            ("failure_event_id", failure_event_id),
            ("reason", reason),
            ("agent_id", agent_id),
        ):
            if not isinstance(value, str) or not value.strip():
                return Result(
                    success=False,
                    message=f"{name} must be nonempty text",
                    code=ErrorCode.INVALID_INPUT,
                )
        if op_id is not None and (not isinstance(op_id, str) or not op_id.strip()):
            return Result(
                success=False, message="op_id must be nonempty text", code=ErrorCode.INVALID_INPUT
            )
        request = {
            "operation": "retry-task",
            "task_id": task_id,
            "failure_event_id": failure_event_id,
            "agent_id": agent_id,
            "reason": reason,
        }
        try:

            def body(tx: _Tx) -> Result:
                cached = self._cached_op(op_id)
                if cached is not None:
                    if not cached.success or any(
                        cached.data.get(key) != value for key, value in request.items()
                    ):
                        return Result(
                            success=False,
                            message="op_id already belongs to a different request",
                            code=ErrorCode.INVALID_INPUT,
                        )
                    return Result(
                        success=True,
                        message="Retry already applied; returned state is historical, not current ownership",
                        data={**cached.data, "already_applied": True},
                    )
                if task_id not in tx.graph.nodes:
                    return Result(
                        success=False,
                        message=f"Task {task_id} not found",
                        code=ErrorCode.TASK_NOT_FOUND,
                    )
                node = tx.graph.nodes[task_id]
                if node.state != NodeState.FAILED:
                    return Result(
                        success=False,
                        message=f"Task {task_id} is not FAILED (current: {node.state.name})",
                        data={"task_id": task_id, "state": node.state.name},
                        code=ErrorCode.INVALID_INPUT,
                    )
                failure = latest_task_failure(self._storage.events.read_all(), task_id)
                if failure is None or failure.id != failure_event_id:
                    return Result(
                        success=False,
                        message="failure_event_id does not match this task's latest native failure",
                        code=ErrorCode.INVALID_INPUT,
                    )

                self._storage.tokens.cleanup(task_id)
                # Reopening is confined to this failure-bound operation;
                # generic edits still cannot reopen terminal tasks.
                node.state = NodeState.PENDING
                node.agent_id = None
                node.claimed_at = None
                node.timeout = None
                node.claim_token = None
                tx.graph.recompute_readiness(task_id)
                tx.graph.increment_epoch()
                tx.emit(
                    EventType.TASK_RETRIED,
                    node_id=task_id,
                    failure_event_id=failure_event_id,
                    agent_id=agent_id,
                    reason=reason,
                    new_state=node.state.name,
                )
                return tx.ok(
                    Result(
                        success=True,
                        message=f"Task {task_id} reopened as {node.state.name}; no claim was issued",
                        data={**request, "state": node.state.name, "already_applied": False},
                    )
                )

            return self._transact(body, op_id)
        except Exception as error:
            return Result(
                success=False, message=f"Operation failed: {error}", code=ErrorCode.INTERNAL_ERROR
            )

    def renew(
        self,
        task_id: str,
        *,
        agent_id: str | None = None,
        token: int | None = None,
        timeout: float | None = None,
    ) -> Result:
        """Renew the lease on an active task with a heartbeat.

        The heartbeat is a compare-and-swap of the task's own heartbeat; it
        writes no state and no event and does not change the fencing epoch.
        Validation first uses the local copy of the state and heartbeat; if
        that copy is outdated the push is rejected and the renewal repeats on
        freshly read state. A claim whose lease already expired is released
        instead and reported stale, whether or not the task is published.
        """
        if token is None:
            return Result(
                success=False,
                message="Fencing token is required.",
                code=ErrorCode.STALE_TOKEN,
            )
        failure: LockError | None = None
        try:
            for attempt in range(_RENEW_ATTEMPTS):
                fresh = attempt > 0
                with self._storage.renewal_view(fresh=fresh):
                    graph = self._load_graph()
                    heartbeats = self._storage.heartbeats.current()
                    node = graph.nodes.get(task_id)
                    if not fresh and (node is None or task_id not in heartbeats):
                        # The local copy may predate this claim; an absent
                        # heartbeat proves nothing about it.
                        continue
                    now = time.time()
                    refused = self._renewal_refusal(node, task_id, agent_id, token, timeout)
                    if refused is not None:
                        if fresh:
                            return refused
                        continue
                    assert node is not None and node.agent_id is not None
                    heartbeat = heartbeats.get(task_id)
                    if node.is_timed_out(now, heartbeat):
                        # An expired lease is never revived. Confirm the expiry
                        # on fresh state before releasing the claim.
                        if fresh:
                            break
                        continue
                    lease = float(timeout) if timeout is not None else node.lease_timeout(heartbeat)
                    beat = self._storage.heartbeats.make(
                        task_id, node.agent_id, token, renewed_at=now, timeout=lease
                    )
                    try:
                        self._storage.heartbeats.renew([beat])
                    except StateConflictError:
                        continue
                    except LockError as error:
                        # Nothing landed (the refs were read back unchanged), so
                        # repeating the heartbeat on fresh data is safe.
                        failure = error
                        continue
                    return Result(
                        success=True,
                        message=f"Task {task_id} lease renewed",
                        data={"task_id": task_id, "renewed_at": now, "timeout": lease},
                    )
            else:
                if failure is not None:
                    raise failure
                return Result(
                    success=False,
                    message=f"Task {task_id} heartbeat kept changing; renewal not confirmed",
                    code=ErrorCode.STATE_CONFLICT,
                )
            return self._release_expired(task_id, token)
        except Exception as e:
            return Result(
                success=False, message=f"Operation failed: {e}", code=ErrorCode.INTERNAL_ERROR
            )

    def _renewal_refusal(
        self,
        node: Node | None,
        task_id: str,
        agent_id: str | None,
        token: int,
        timeout: float | None,
    ) -> Result | None:
        """The result refusing this renewal, or None when it may proceed."""
        if node is None:
            return Result(
                success=False,
                message=f"Task {task_id} not found",
                code=ErrorCode.TASK_NOT_FOUND,
            )
        if node.state != NodeState.ACTIVE:
            return Result(
                success=False,
                message=f"Task {task_id} is not active (current: {node.state.name})",
                data={"state": node.state.name},
                code=ErrorCode.TASK_NOT_ACTIVE,
            )
        if node.claim_token is None or token != node.claim_token:
            return _stale_token_result(token, node.claim_token)
        if node.task_input is not None:
            if agent_id is None:
                return Result(
                    success=False,
                    message="Published tasks require the claiming agent identity",
                    code=ErrorCode.INVALID_INPUT,
                )
            if timeout is not None and (
                type(timeout) not in (int, float) or not 1 <= timeout <= 86400
            ):
                return Result(
                    success=False,
                    message="Lease must be between 1 and 86400 seconds",
                    code=ErrorCode.INVALID_INPUT,
                )
        if agent_id is not None and node.agent_id != agent_id:
            return Result(
                success=False,
                message=f"Task {task_id} is claimed by '{node.agent_id}', not '{agent_id}'.",
                data={"claimed_by": node.agent_id, "caller": agent_id},
                code=ErrorCode.WRONG_AGENT,
            )
        return None

    def _release_expired(self, task_id: str, token: int) -> Result:
        """Release an expired claim the renewal found; report it stale."""

        def body(tx: _Tx) -> Result:
            node = tx.graph.nodes.get(task_id)
            if node is not None and node.claim_token == token:
                if self._release_if_timed_out(tx, node, time.time()):
                    tx.save()
                    return _stale_token_result(token, None)
                return Result(
                    success=False,
                    message=f"Task {task_id} lease is still valid; renew again",
                    code=ErrorCode.STATE_CONFLICT,
                )
            return _stale_token_result(token, node.claim_token if node else None)

        return self._transact(body)

    def _finish(
        self,
        task_id: str,
        *,
        agent_id: str | None = None,
        token: int | None = None,
        op_id: str | None = None,
        is_success: bool = True,
        is_release: bool = False,
        summary: str = "",
        critical: dict[str, Any] | None = None,
        artifacts: str = "",
        deliverables: dict[str, str] | None = None,
        should_cascade: bool = False,
    ) -> Result:
        """Internal finish logic shared by complete/fail/release."""
        if token is None:
            return Result(
                success=False,
                message=(
                    "Fencing token is required. "
                    "Call get-task first to claim the task and receive a token."
                ),
                code=ErrorCode.STALE_TOKEN,
            )
        try:

            def body(tx: _Tx) -> Result:
                cached = self._cached_op(op_id)
                if cached is not None:
                    return cached
                if task_id not in tx.graph.nodes:
                    return Result(
                        success=False,
                        message=f"Task {task_id} not found",
                        code=ErrorCode.TASK_NOT_FOUND,
                    )

                node = tx.graph.nodes[task_id]

                if node.state != NodeState.ACTIVE:
                    return Result(
                        success=False,
                        message=f"Task {task_id} is not active (current: {node.state.name})",
                        data={"state": node.state.name},
                        code=ErrorCode.TASK_NOT_ACTIVE,
                    )

                if node.claim_token is None or token != node.claim_token:
                    return _stale_token_result(token, node.claim_token)

                if node.task_input is not None:
                    if agent_id is None:
                        return Result(
                            success=False,
                            message="Published tasks require the claiming agent identity",
                            code=ErrorCode.INVALID_INPUT,
                        )
                    if self._release_if_timed_out(tx, node, time.time()):
                        tx.save()
                        return _stale_token_result(token, None)
                ownership = (
                    {"agent_id": node.agent_id, "claim_token": token}
                    if node.task_input is not None
                    else {}
                )

                if agent_id is not None and node.agent_id != agent_id:
                    return Result(
                        success=False,
                        message=(
                            f"Task {task_id} is claimed by '{node.agent_id}', "
                            f"not '{agent_id}'. Only the claiming agent can finish it."
                        ),
                        data={"claimed_by": node.agent_id, "caller": agent_id},
                        code=ErrorCode.WRONG_AGENT,
                    )

                tx.graph.increment_epoch()

                if is_release:
                    node.update_state(NodeState.READY)
                    node.agent_id = None
                    node.claimed_at = None
                    node.timeout = None
                    node.claim_token = None

                    message = f"Task {task_id} released and is now available"
                    if summary:
                        message += f" (reason: {summary})"

                    self._storage.tokens.invalidate(task_id, reason="released")
                    tx.emit(EventType.TASK_RELEASED, node_id=task_id, reason=summary, **ownership)
                    return tx.ok(
                        Result(
                            success=True,
                            message=message,
                            data={"task_id": task_id, "outcome": "RELEASED", "state": "READY"},
                        )
                    )

                elif is_success:
                    node_promises = tx.graph.get_node_promises(task_id)
                    complete_tips = tips.on_complete(
                        summary=summary,
                        critical=critical or {},
                        artifacts=artifacts,
                        promises=[
                            {"to_node": p["to_node"], "promise": p["promise"]}
                            for p in node_promises
                        ],
                        deliverables=deliverables,
                        has_dependents=len(tx.graph.get_dependents(task_id)) > 0,
                    )

                    if tips.has_required(complete_tips):
                        return Result(
                            success=False,
                            message=tips.required_messages(complete_tips)[0],
                            code=ErrorCode.UNADDRESSED_PROMISES,
                        )

                    node.update_state(NodeState.COMPLETED)
                    node.agent_id = None
                    node.claimed_at = None
                    node.timeout = None
                    node.claim_token = None

                    if node.context is None:
                        node.context = Context()
                    if summary:
                        node.context.summary = summary
                    if critical:
                        node.context.critical.update(critical)
                    if artifacts:
                        node.context.artifacts = str(artifacts)

                    prov = Provenance(produced_at=time.time())
                    git_ref = _get_git_ref()
                    if git_ref:
                        prov.git_ref = git_ref
                    if deliverables:
                        prov.deliverables = deliverables
                    node.context.provenance = prov

                    unblocked = tx.graph.notify_completion(task_id)

                    message = f"Task {task_id} completed"
                    if unblocked:
                        message += f", unblocked: {unblocked}"
                    message = tips.append_tips(message, complete_tips)

                    self._storage.tokens.cleanup(task_id)
                    ctx_data: dict[str, Any] = {"provenance": prov.to_dict()}
                    if summary:
                        ctx_data["summary"] = summary
                    if critical:
                        ctx_data["critical"] = critical
                    if artifacts:
                        ctx_data["artifacts_ref"] = self._storage.content.put(str(artifacts))
                    tx.emit(
                        EventType.TASK_COMPLETED,
                        node_id=task_id,
                        unblocked=unblocked,
                        context=ctx_data if ctx_data else None,
                        **ownership,
                    )
                    return tx.ok(
                        Result(
                            success=True,
                            message=message,
                            data={
                                "task_id": task_id,
                                "outcome": "COMPLETED",
                                "unblocked_tasks": unblocked,
                            },
                        )
                    )

                else:
                    affected = [task_id]
                    node.agent_id = None
                    node.claimed_at = None
                    node.timeout = None
                    node.claim_token = None

                    if should_cascade:

                        def fail_recursive(nid: str) -> None:
                            current = tx.graph.nodes[nid]
                            if current.state.is_terminal():
                                return
                            current.update_state(NodeState.FAILED)
                            current.agent_id = None
                            current.claimed_at = None
                            current.timeout = None
                            current.claim_token = None
                            affected.append(nid)
                            for dep in tx.graph.get_dependents(nid):
                                fail_recursive(dep.id)

                        fail_recursive(task_id)
                    else:
                        node.update_state(NodeState.FAILED)

                    message = f"Task {task_id} failed"
                    if should_cascade and len(affected) > 1:
                        message += f" (cascaded to {len(affected) - 1} dependent tasks)"
                    if summary:
                        message += f": {summary}"

                    fail_tips = tips.on_fail(
                        cascade=should_cascade,
                        affected_count=len(affected),
                    )
                    message = tips.append_tips(message, fail_tips)

                    self._storage.tokens.cleanup(task_id)
                    tx.emit(
                        EventType.TASK_FAILED,
                        node_id=task_id,
                        reason=summary,
                        affected=affected,
                        cascade=should_cascade,
                        **ownership,
                    )
                    return tx.ok(
                        Result(
                            success=True,
                            message=message,
                            data={
                                "task_id": task_id,
                                "outcome": "FAILED",
                                "affected_tasks": affected,
                                "cascade": should_cascade,
                            },
                        )
                    )

            return self._transact(body, op_id)

        except Exception as e:
            return Result(
                success=False, message=f"Operation failed: {e}", code=ErrorCode.INTERNAL_ERROR
            )
