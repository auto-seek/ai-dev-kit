# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""File-backed claim heartbeats in ``<base>/heartbeats/<key>.json``.

Callers hold the storage lock, so a renewal can never race another writer
here and ``renew`` needs no compare-and-swap.
"""

from __future__ import annotations

import json
import os
from collections.abc import Mapping, Sequence
from pathlib import Path

from cascade import __version__
from cascade.types import Heartbeat, heartbeat_key, validate_node_id


def parse_heartbeat(text: str, *, namespace: str, key: str) -> tuple[Heartbeat | None, str]:
    """A stored heartbeat, or None with the reason it cannot be used.

    ``key`` is where the heartbeat was stored (its ref or file key), which
    must be ``heartbeat_key`` of the payload's task.
    """
    try:
        data = json.loads(text)
    except ValueError as exc:
        return None, f"payload is not JSON: {exc}"
    try:
        heartbeat = Heartbeat.from_payload(data)
    except ValueError as exc:
        return None, f"payload is invalid: {exc}"
    if heartbeat.namespace != namespace:
        return None, f"namespace {heartbeat.namespace!r} is not {namespace!r}"
    if heartbeat_key(heartbeat.task_id) != key:
        return None, f"task {heartbeat.task_id!r} does not belong under key {key}"
    return heartbeat, ""


def stale_heartbeats(
    current: Mapping[str, Heartbeat], active: Mapping[str, tuple[str, int]]
) -> list[str]:
    """Task IDs whose heartbeat no longer belongs to an ACTIVE claim."""
    return [
        task_id
        for task_id, heartbeat in current.items()
        if active.get(task_id) != (heartbeat.agent_id, heartbeat.claim_token)
    ]


def make_heartbeat(
    namespace: str,
    task_id: str,
    agent_id: str,
    claim_token: int,
    renewed_at: float,
    timeout: float | None,
) -> Heartbeat:
    return Heartbeat(
        namespace=namespace,
        task_id=task_id,
        agent_id=agent_id,
        claim_token=claim_token,
        renewed_at=renewed_at,
        timeout=timeout,
        runtime=__version__,
    )


class FileHeartbeatStore:
    def __init__(self, base_dir: Path | str, namespace: str = "default") -> None:
        self._dir = Path(base_dir) / "heartbeats"
        self._namespace = namespace

    def make(
        self,
        task_id: str,
        agent_id: str,
        claim_token: int,
        renewed_at: float,
        timeout: float | None,
    ) -> Heartbeat:
        return make_heartbeat(self._namespace, task_id, agent_id, claim_token, renewed_at, timeout)

    def _path(self, task_id: str) -> Path:
        validate_node_id(task_id)
        return self._dir / f"{heartbeat_key(task_id)}.json"

    def _scan(self) -> tuple[dict[str, Heartbeat], list[dict[str, str]]]:
        found: dict[str, Heartbeat] = {}
        malformed: list[dict[str, str]] = []
        if not self._dir.is_dir():
            return found, malformed
        for path in sorted(self._dir.glob("*.json")):
            try:
                text = path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError) as exc:
                heartbeat, reason = None, f"payload is unreadable: {exc}"
            else:
                heartbeat, reason = parse_heartbeat(text, namespace=self._namespace, key=path.stem)
            if heartbeat is None:
                # A malformed heartbeat extends nothing; the claim time still counts.
                malformed.append({"key": path.stem, "path": str(path), "reason": reason})
            else:
                found[heartbeat.task_id] = heartbeat
        return found, malformed

    def current(self) -> dict[str, Heartbeat]:
        return self._scan()[0]

    def malformed(self) -> list[dict[str, str]]:
        return self._scan()[1]

    def _write(self, heartbeat: Heartbeat) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)
        path = self._path(heartbeat.task_id)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(heartbeat.to_payload(), sort_keys=True), encoding="utf-8")
        os.replace(tmp, path)

    def stage(self, started: Sequence[Heartbeat], active: Mapping[str, tuple[str, int]]) -> None:
        for task_id in stale_heartbeats(self.current(), active):
            self._path(task_id).unlink(missing_ok=True)
        for heartbeat in started:
            self._write(heartbeat)

    def renew(self, beats: Sequence[Heartbeat]) -> None:
        for heartbeat in beats:
            self._write(heartbeat)
