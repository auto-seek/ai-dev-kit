# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Storage components for Cascade persistence."""

from cascade.storage.content import ContentStore, GitContentStore, LocalContentStore
from cascade.storage.file_storage import FileStorage, StorageScope
from cascade.storage.git_ref_lease import GitRefLease
from cascade.storage.git_storage import GitStorage
from cascade.storage.protocol import StorageProtocol

__all__ = [
    "ContentStore",
    "FileStorage",
    "GitRefLease",
    "GitStorage",
    "GitContentStore",
    "LocalContentStore",
    "StorageProtocol",
    "StorageScope",
]

try:
    from cascade.storage.redis_storage import RedisStorage

    __all__ += ["RedisStorage"]
except ImportError:
    pass
