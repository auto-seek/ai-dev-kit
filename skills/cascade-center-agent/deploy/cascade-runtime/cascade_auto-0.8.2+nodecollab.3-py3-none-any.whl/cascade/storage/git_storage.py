# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Git-backed Cascade storage for service-free cross-machine coordination.

Each transaction is materialized into a dedicated local cache, executed using
the proven file-backed subcomponents, then published with one atomic
expected-OID push. There is no transaction lease: a writer that loses the
compare-and-swap publishes nothing and the caller retries on fresh state.
Coordination data never enters the caller's product worktree.

Lease renewals do not touch the state. Each ACTIVE claim has a heartbeat ref
``refs/heads/cascade-heartbeat/<namespace>/<sha256(task_id)>`` whose commit
message carries the renewal; renewing is one CAS push of that ref alone.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import time
import uuid
from collections.abc import Generator, Mapping, Sequence
from contextlib import contextmanager
from pathlib import Path

from filelock import FileLock, Timeout

from cascade import __version__
from cascade.core.cascade import Cascade
from cascade.errors import (
    LockContentionError,
    LockError,
    StateConflictError,
    StorageCorruptionError,
)
from cascade.storage._serde import deserialize_graph
from cascade.storage.content import ContentStore
from cascade.storage.file_storage import FileStorage
from cascade.storage.git_ref_lease import (
    _push_accepted,
    _redact_credentials,
    _validate_namespace,
)
from cascade.storage.heartbeat_store import make_heartbeat, parse_heartbeat
from cascade.storage.protocol import (
    EventStoreProtocol,
    HeartbeatStoreProtocol,
    OpLogProtocol,
    TokenStoreProtocol,
)
from cascade.storage.token_store import CancelNotifier
from cascade.types import HEARTBEAT_MAX_BYTES, Heartbeat, TokenStatus, heartbeat_key

RUNTIME = __version__
_HEARTBEAT_KEY = re.compile(r"[0-9a-f]{64}")
# (ref, new OID or None to delete, expected OID or None for absent)
RefUpdate = tuple[str, str | None, str | None]


def _refused_as_stale(result: subprocess.CompletedProcess[str], refs: int) -> bool:
    """Git rejected every ref locally because an expected OID no longer held."""
    rejected = [line for line in result.stdout.splitlines() if line.startswith("!")]
    return (
        len(rejected) == refs
        and all("[remote rejected]" not in line for line in rejected)
        and any("(stale info)" in line for line in rejected)
    )


class _NoContent:
    """Content store for a claims-only graph read: artifact texts stay unloaded."""

    def put(self, content: str) -> str:
        raise LockError("A renewal view cannot store content")

    def get(self, ref: str) -> str | None:
        return None

    def exists(self, ref: str) -> bool:
        return False


class _GitHeartbeats:
    """``HeartbeatStoreProtocol`` view over a GitStorage's heartbeat refs."""

    def __init__(self, storage: GitStorage) -> None:
        self._storage = storage

    def make(
        self,
        task_id: str,
        agent_id: str,
        claim_token: int,
        renewed_at: float,
        timeout: float | None,
    ) -> Heartbeat:
        return make_heartbeat(
            self._storage.namespace, task_id, agent_id, claim_token, renewed_at, timeout
        )

    def current(self) -> dict[str, Heartbeat]:
        return self._storage._current_heartbeats()

    def malformed(self) -> list[dict[str, str]]:
        return self._storage._malformed_heartbeats()

    def stage(self, started: Sequence[Heartbeat], active: Mapping[str, tuple[str, int]]) -> None:
        self._storage._stage_heartbeats(started, active)

    def renew(self, beats: Sequence[Heartbeat]) -> None:
        self._storage._renew_heartbeats(beats)


class GitStorage:
    """StorageProtocol implementation backed by a Git remote.

    ``cache_dir`` must be local to one machine/container. Independent agents
    use independent caches and coordinate only through the remote refs.
    """

    def __init__(
        self,
        remote: str,
        *,
        namespace: str = "default",
        cache_dir: Path | str | None = None,
    ) -> None:
        if not remote:
            raise ValueError("remote is required")
        _validate_namespace(namespace)
        remote_key = hashlib.sha256(remote.encode("utf-8")).hexdigest()[:16]
        root = (
            Path(cache_dir)
            if cache_dir is not None
            else Path.home() / ".cache" / "cascade" / "git" / remote_key / namespace
        )
        self.remote = remote
        self.namespace = namespace
        self.cache_dir = root
        # Runtimes before 0.8.2+nodecollab.3 use ``state-repo`` and ``lease.git``
        # here; a separate working copy keeps either from reusing the other's.
        self._repo_dir = root / "git-state"
        self._generation_file = root / "git-state.generation"
        self._data_dir = self._repo_dir / "data"
        self._state_ref = f"refs/heads/cascade-state/{namespace}"
        self._cache_ref = f"refs/cascade-cache/state/{namespace}"
        self._heartbeat_prefix = f"refs/heads/cascade-heartbeat/{namespace}/"
        self._heartbeat_cache_prefix = f"refs/cascade-cache/heartbeat/{namespace}/"
        self._writer_id = f"git-storage:{os.getpid()}:{uuid.uuid4().hex}"
        self._base_oid: str | None = None
        # State OID the in-memory FileStorage was built from while the
        # worktree matched it. ``None`` forces a rebuild on the next sync,
        # for example after a transaction body that may have diverged.
        self._bound_oid: str | None = None
        # (state OID or None, generation token, file fingerprint) while this
        # process knows the worktree equals that commit. Any process about to
        # change the worktree first writes a new generation token, and any
        # other edit changes the fingerprint, so neither copy is trusted then.
        self._clean: tuple[str | None, str, str] | None = None
        self._trees: dict[str, str] = {}
        self._written: dict[str, Heartbeat] = {}
        # Local cache refs: the state commit, and heartbeats by key with their
        # payloads (None if malformed).
        self._cached_state: str | None = None
        self._heartbeat_refs: dict[str, str] = {}
        self._heartbeat_payloads: dict[str, Heartbeat | None] = {}
        self._heartbeat_errors: dict[str, str] = {}
        self._staged: tuple[list[Heartbeat], dict[str, tuple[str, int]]] | None = None
        self._open: str | None = None
        self._notifications: list[tuple[CancelNotifier, TokenStatus]] = []
        self._empty_tree: str | None = None
        self._cache_lock = FileLock(root / ".local-cache.lock")
        self._ensure_repo()
        self._file = self._new_file_storage()
        self.events: EventStoreProtocol = self._file.events
        self.tokens: TokenStoreProtocol = self._file.tokens
        self.ops: OpLogProtocol = self._file.ops
        self.content: ContentStore = self._file.content
        self.heartbeats: HeartbeatStoreProtocol = _GitHeartbeats(self)
        self._refresh_snapshot()

    @property
    def state_ref(self) -> str:
        return self._state_ref

    @property
    def state_oid(self) -> str | None:
        """State commit the local cache holds; ``None`` for an unwritten namespace.

        Inside :meth:`lock` or :meth:`read_snapshot` every read comes from
        this one commit.
        """
        return self._base_oid

    def heartbeat_ref(self, task_id: str) -> str:
        """Remote heartbeat ref of a task."""
        return f"{self._heartbeat_prefix}{heartbeat_key(task_id)}"

    # ------------------------------------------------------------------
    # Git plumbing
    # ------------------------------------------------------------------

    def _run(
        self,
        *args: str,
        input_text: str | None = None,
        check: bool = True,
        git_dir: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        cmd = ["git"]
        if git_dir:
            cmd.extend(["-C", str(self._repo_dir)])
        cmd.extend(args)
        env = os.environ.copy()
        env.setdefault("GIT_AUTHOR_NAME", "Cascade")
        env.setdefault("GIT_AUTHOR_EMAIL", "cascade@localhost")
        env.setdefault("GIT_COMMITTER_NAME", "Cascade")
        env.setdefault("GIT_COMMITTER_EMAIL", "cascade@localhost")
        failure: LockError | None = None
        result: subprocess.CompletedProcess[str] | None = None
        try:
            result = subprocess.run(
                cmd,
                input=input_text,
                capture_output=True,
                text=True,
                errors="replace",
                env=env,
                timeout=60,
            )
        except subprocess.TimeoutExpired:
            safe_cmd = _redact_credentials(" ".join(cmd))
            failure = LockError(f"Git storage command timed out: {safe_cmd}")
        except OSError as exc:
            safe_cmd = _redact_credentials(" ".join(cmd))
            detail = _redact_credentials(str(exc))
            failure = LockError(f"Git storage command could not start: {safe_cmd}: {detail}")
        if failure is not None:
            raise failure
        assert result is not None
        if check and result.returncode != 0:
            detail = _redact_credentials((result.stderr or result.stdout).strip())
            safe_cmd = _redact_credentials(" ".join(cmd))
            raise LockError(f"Git storage command failed: {safe_cmd}: {detail}")
        return result

    def _ensure_repo(self) -> None:
        self._repo_dir.mkdir(parents=True, exist_ok=True)
        if not (self._repo_dir / ".git").exists():
            self._run("init", "--quiet", str(self._repo_dir), git_dir=False)
            # Automatic maintenance runs inside the triggering command, under
            # the cache lock, never in the background beside the next one: a
            # detached repack racing new objects can drop them.
            self._run("config", "maintenance.autoDetach", "false")
            self._run("config", "gc.autoDetach", "false")

    def _remote_refs(self, *refs: str) -> dict[str, str | None]:
        """Read several remote refs with one ls-remote, matching names exactly."""
        result = self._run("ls-remote", self.remote, *refs, git_dir=False)
        found: dict[str, str] = {}
        for line in result.stdout.splitlines():
            oid, _, name = line.partition("\t")
            if name in refs:
                found[name] = oid.strip()
        return {ref: found.get(ref) for ref in refs}

    def _remote_ref_oid(self, ref: str) -> str | None:
        return self._remote_refs(ref)[ref]

    def _observe(self) -> tuple[str | None, dict[str, str]]:
        """The remote state OID and heartbeat OIDs by key, from one ls-remote."""
        result = self._run(
            "ls-remote",
            self.remote,
            self._state_ref,
            f"{self._heartbeat_prefix}*",
            git_dir=False,
        )
        state: str | None = None
        heartbeats: dict[str, str] = {}
        for line in result.stdout.splitlines():
            oid, _, name = line.partition("\t")
            oid = oid.strip()
            if name == self._state_ref:
                state = oid
            elif name.startswith(self._heartbeat_prefix):
                key = name[len(self._heartbeat_prefix) :]
                if _HEARTBEAT_KEY.fullmatch(key):
                    heartbeats[key] = oid
        return state, heartbeats

    def _read_cache_refs(self) -> None:
        """Load the cached state OID and heartbeat refs with payloads in one call."""
        listed = self._run(
            "for-each-ref",
            "--format=%(refname)%00%(objectname)%00%(contents)%00",
            self._cache_ref,
            self._heartbeat_cache_prefix,
        ).stdout
        state: str | None = None
        refs: dict[str, str] = {}
        payloads: dict[str, Heartbeat | None] = {}
        errors: dict[str, str] = {}
        for record in listed.split("\0\n"):
            if not record.strip():
                continue
            name, _, rest = record.partition("\0")
            oid, _, message = rest.partition("\0")
            if name == self._cache_ref:
                state = oid
                continue
            key = name[len(self._heartbeat_cache_prefix) :]
            if name.startswith(self._heartbeat_cache_prefix) and _HEARTBEAT_KEY.fullmatch(key):
                refs[key] = oid
                payloads[key], reason = parse_heartbeat(message, namespace=self.namespace, key=key)
                if reason:
                    errors[key] = reason
        self._cached_state = state
        self._heartbeat_refs = refs
        self._heartbeat_payloads = payloads
        self._heartbeat_errors = errors

    def _update_local_refs(self, changes: Mapping[str, str | None]) -> None:
        """Set (OID) or delete (None) local refs in one update-ref call."""
        if not changes:
            return
        commands = "".join(
            f"update {ref} {oid}\n" if oid is not None else f"delete {ref}\n"
            for ref, oid in changes.items()
        )
        self._run("update-ref", "--stdin", input_text=commands)

    def _clear_worktree(self) -> None:
        for child in self._repo_dir.iterdir():
            if child.name == ".git":
                continue
            if child.is_dir() and not child.is_symlink():
                shutil.rmtree(child)
            else:
                child.unlink()

    def _new_file_storage(self) -> FileStorage:
        return FileStorage(self._data_dir, token_dispatch=self._defer_notification)

    def _bind_file_storage(self) -> None:
        self._file = self._new_file_storage()
        self.events = self._file.events
        self.tokens = self._file.tokens
        self.ops = self._file.ops
        self.content = self._file.content

    def _defer_notification(self, notifier: CancelNotifier, token: TokenStatus) -> None:
        # A cancellation inside a transaction only fires once its commit lands;
        # a transaction that loses its CAS and is redone never notifies early.
        if self._open == "write":
            self._notifications.append((notifier, token))
        else:
            notifier.notify(token)

    # ------------------------------------------------------------------
    # Synchronization
    # ------------------------------------------------------------------

    def _sync(self, *, materialize: bool = True) -> None:
        """Bring the cache to the remote state and heartbeats with one fetch.

        A fetch whose refs did not move transfers nothing and costs the same
        single connection as ls-remote, so the remote is never asked twice.
        A fresh cache takes only the newest snapshot; later fetches are
        incremental and do not grow the shallow boundary. With
        ``materialize`` the worktree is made equal to the state commit.
        """
        if self._cached_state is None:
            self._read_cache_refs()
        options = ["--quiet", "--no-tags", "--prune"]
        if self._cached_state is None:
            options.append("--depth=1")
        try:
            self._run(
                "fetch",
                *options,
                self.remote,
                f"+{self._state_ref}:{self._cache_ref}",
                # The glob also prunes heartbeats that disappeared remotely.
                f"+{self._heartbeat_prefix}*:{self._heartbeat_cache_prefix}*",
            )
        except LockError:
            # The state ref may not exist yet; anything else stays an error.
            if self._observe()[0] is not None:
                raise
            # Without a state there is no claim for a heartbeat to extend.
            self._update_local_refs({self._cache_ref: None})
            self._read_cache_refs()
            self._forget_heartbeats(set(self._heartbeat_refs))
            self._cached_state = None
            if materialize:
                self._materialize_empty()
            return
        self._read_cache_refs()
        if materialize:
            assert self._cached_state is not None
            self._materialize(self._cached_state)

    def _forget_heartbeats(self, keys: set[str]) -> None:
        self._update_local_refs({f"{self._heartbeat_cache_prefix}{key}": None for key in keys})
        for key in keys:
            self._heartbeat_refs.pop(key, None)
            self._heartbeat_payloads.pop(key, None)
            self._heartbeat_errors.pop(key, None)

    def _malformed_heartbeats(self) -> list[dict[str, str]]:
        if self._open is None:
            raise LockError("Heartbeats are read inside lock(), read_snapshot() or renewal_view()")
        return [
            {
                "key": key,
                "ref": f"{self._heartbeat_prefix}{key}",
                "oid": self._heartbeat_refs[key],
                "reason": reason,
            }
            for key, reason in sorted(self._heartbeat_errors.items())
        ]

    def _current_heartbeats(self) -> dict[str, Heartbeat]:
        if self._open is None:
            raise LockError("Heartbeats are read inside lock(), read_snapshot() or renewal_view()")
        return {
            heartbeat.task_id: heartbeat
            for heartbeat in self._heartbeat_payloads.values()
            if heartbeat is not None
        }

    def _generation(self) -> str:
        try:
            return self._generation_file.read_text(encoding="utf-8")
        except FileNotFoundError:
            return ""

    def _bump_generation(self) -> str:
        """Announce to every process sharing this cache that the worktree may change."""
        token = uuid.uuid4().hex
        tmp = self._generation_file.with_name(f"{self._generation_file.name}.{token}.tmp")
        tmp.write_text(token, encoding="utf-8")
        os.replace(tmp, self._generation_file)
        return token

    def _fingerprint(self) -> str:
        """Names, sizes, inodes and mtimes of every worktree file (no Git process)."""
        digest = hashlib.sha256()
        for directory, subdirs, files in os.walk(self._repo_dir):
            if Path(directory) == self._repo_dir and ".git" in subdirs:
                subdirs.remove(".git")
            subdirs.sort()
            for name in sorted(files):
                path = os.path.join(directory, name)
                info = os.lstat(path)
                relative = os.path.relpath(path, self._repo_dir)
                digest.update(
                    f"{relative}\0{info.st_size}\0{info.st_ino}\0{info.st_mtime_ns}\n".encode()
                )
        return digest.hexdigest()

    def _mark_clean(self, oid: str | None, generation: str) -> None:
        self._clean = (oid, generation, self._fingerprint())

    def _trusted_clean(self) -> tuple[bool, str | None]:
        """``(True, oid)`` when the worktree still equals the commit this process left."""
        if self._clean is None:
            return False, None
        oid, generation, fingerprint = self._clean
        if generation != self._generation() or fingerprint != self._fingerprint():
            return False, None
        return True, oid

    def _materialize(self, oid: str) -> None:
        """Make the worktree exactly the cached commit ``oid``, reusing a clean copy."""
        token = self._generation()
        trusted, known = self._trusted_clean()
        if trusted and known == oid:
            pass
        elif trusted and known is not None and self._fast_forward(known, oid):
            self._bound_oid = None
        elif self._worktree_matches(oid):
            self._mark_clean(oid, token)
        else:
            token = self._bump_generation()
            self._clear_worktree()
            self._run("read-tree", oid)
            self._run("checkout-index", "--all", "--force")
            self._mark_clean(oid, token)
            self._bound_oid = None
        self._base_oid = oid
        if self._bound_oid != oid:
            self._bind_file_storage()
            self._bound_oid = oid

    def _fast_forward(self, current: str, oid: str) -> bool:
        """Move a worktree known to equal ``current`` to ``oid``, rewriting only changed files."""
        token = self._bump_generation()
        self._clean = None
        moved = self._run("read-tree", "-m", "-u", current, oid, check=False)
        if moved.returncode != 0:
            return False
        self._mark_clean(oid, token)
        return True

    def _materialize_empty(self) -> None:
        token = self._bump_generation()
        self._clear_worktree()
        self._run("read-tree", "--empty")
        self._mark_clean(None, token)
        self._base_oid = None
        self._bind_file_storage()
        self._bound_oid = None

    def _worktree_tree(self) -> str:
        # Stage from the worktree root rather than naming ``data`` directly.
        # A read-only operation on a brand-new namespace may run before
        # FileStorage has created any data files. ``git add ... data`` treats
        # that absent pathspec as an error, whereas ``.`` is a valid no-op and
        # still stages a later deletion of the whole data tree. ``--force``
        # prevents a user's global Git excludes (for example a broad
        # ``*.json`` rule) from silently dropping coordination files in this
        # isolated internal repository.
        self._run("add", "--all", "--force", "--", ".")
        return self._run("write-tree").stdout.strip()

    def _tree_of(self, commit: str) -> str:
        if commit not in self._trees:
            self._trees[commit] = self._run("rev-parse", f"{commit}^{{tree}}").stdout.strip()
        return self._trees[commit]

    def _base_tree(self) -> str:
        if self._base_oid:
            return self._tree_of(self._base_oid)
        return self._empty_tree_oid()

    def _empty_tree_oid(self) -> str:
        if self._empty_tree is None:
            self._empty_tree = self._run("mktree", input_text="").stdout.strip()
        return self._empty_tree

    def _worktree_matches(self, oid: str) -> bool:
        """Whether publishing the worktree now would reproduce ``oid``'s tree."""
        try:
            return self._worktree_tree() == self._tree_of(oid)
        except LockError:
            # A damaged local index is rebuilt from the cached commit.
            return False

    def _refresh_snapshot(self) -> None:
        try:
            with self._cache_lock.acquire(timeout=10):
                self._sync()
        except Timeout as exc:
            raise LockContentionError("Could not acquire local Git storage cache lock") from exc

    # ------------------------------------------------------------------
    # Publication
    # ------------------------------------------------------------------

    def _state_message(self, title: str, *details: str) -> str:
        lines = [f"{title} {self.namespace}", "", f"holder={self._writer_id}", f"runtime={RUNTIME}"]
        lines.extend(details)
        lines.append(f"created_at={time.time()}")
        return "\n".join(lines) + "\n"

    def _commit_state(self) -> str | None:
        """Commit the worktree on top of the base; ``None`` when nothing changed."""
        tree = self._worktree_tree()
        if tree == self._base_tree():
            return None
        args = ["commit-tree", tree]
        if self._base_oid:
            args.extend(["-p", self._base_oid])
        message = self._state_message("cascade state")
        return self._run(*args, input_text=message).stdout.strip()

    def _heartbeat_commit(self, heartbeat: Heartbeat, parent: str | None) -> str:
        if heartbeat.namespace != self.namespace or heartbeat.runtime != RUNTIME:
            raise ValueError("heartbeat namespace or runtime does not match this storage")
        payload = json.dumps(heartbeat.to_payload(), sort_keys=True, separators=(",", ":"))
        Heartbeat.from_payload(json.loads(payload))
        if len(payload.encode("utf-8")) > HEARTBEAT_MAX_BYTES - 512:
            raise ValueError("heartbeat payload exceeds the size limit")
        args = ["commit-tree", self._empty_tree_oid()]
        if parent is not None:
            args.extend(["-p", parent])
        commit = self._run(*args, input_text=payload).stdout.strip()
        self._written[commit] = heartbeat
        return commit

    def _stage_heartbeats(
        self, started: Sequence[Heartbeat], active: Mapping[str, tuple[str, int]]
    ) -> None:
        if self._open != "write":
            raise LockError("Heartbeats are staged inside lock()")
        self._staged = (list(started), dict(active))

    def _staged_heartbeat_updates(self) -> list[RefUpdate]:
        """Refs to change with the state commit: new claims' heartbeats and ended ones."""
        if self._staged is None:
            return []
        started, active = self._staged
        changes: dict[str, tuple[str | None, str | None]] = {}
        for key, heartbeat in self._heartbeat_payloads.items():
            if heartbeat is None:
                # Leave malformed or foreign refs alone; they extend nothing.
                continue
            if active.get(heartbeat.task_id) != (heartbeat.agent_id, heartbeat.claim_token):
                changes[key] = (None, self._heartbeat_refs[key])
        for heartbeat in started:
            key = heartbeat_key(heartbeat.task_id)
            expected = self._heartbeat_refs.get(key)
            changes[key] = (self._heartbeat_commit(heartbeat, expected), expected)
        return [
            (f"{self._heartbeat_prefix}{key}", new, expected)
            for key, (new, expected) in changes.items()
        ]

    def _push_refs(self, updates: Sequence[RefUpdate]) -> None:
        """Apply ``updates`` in one atomic expected-OID push.

        Returns once the targets are observed. Raises ``StateConflictError``
        when another writer moved a ref first (nothing of ours landed) and
        ``LockError`` when nothing moved but the push still failed
        (transport or policy). After a failed or unknown push the refs are
        read back; a state commit that was superseded after landing is
        recognized by ancestry.
        """
        options = ["--porcelain", "--atomic"]
        refspecs = []
        for ref, new, expected in updates:
            options.append(f"--force-with-lease={ref}:{expected or ''}")
            refspecs.append(f"{new or ''}:{ref}")
        try:
            result = self._run("push", *options, self.remote, *refspecs, check=False)
            if _push_accepted(result):
                return
            detail = _redact_credentials((result.stderr or result.stdout).strip())
            if _refused_as_stale(result, len(updates)):
                # Git refused the whole push before sending it: a ref moved.
                raise StateConflictError("A ref moved before this push; nothing was published")
        except LockError as exc:
            if isinstance(exc, StateConflictError):
                raise
            detail = str(exc)
        observed = self._remote_refs(*(ref for ref, _, _ in updates))
        state = next(((new, old) for ref, new, old in updates if ref == self._state_ref), None)
        if state is not None:
            new_state, old_state = state
            now = observed[self._state_ref]
            if now == new_state:
                return
            if now != old_state:
                if new_state is not None and self._landed_under(now, new_state):
                    return
                raise StateConflictError(
                    f"Git state moved during the transaction; nothing was published: {detail}"
                )
            if any(observed[ref] != old for ref, _, old in updates):
                raise StateConflictError(
                    f"A heartbeat moved during the transaction; nothing was published: {detail}"
                )
            raise LockError(
                f"Git ref compare-and-swap command failed for {self._state_ref}: {detail}"
            )
        if all(observed[ref] == new for ref, new, _ in updates):
            return
        if all(observed[ref] == old for ref, _, old in updates):
            raise LockError(f"Git heartbeat compare-and-swap command failed: {detail}")
        raise StateConflictError(f"A heartbeat changed before this renewal: {detail}")

    def _landed_under(self, tip: str | None, commit: str) -> bool:
        """Whether ``commit`` is in the remote state history ending at ``tip``."""
        if tip is None:
            return False
        try:
            self._run(
                "fetch",
                "--quiet",
                "--no-tags",
                self.remote,
                f"+{self._state_ref}:{self._cache_ref}",
            )
        except LockError as exc:
            raise LockError(f"Git state publication outcome is unknown: {exc}") from exc
        result = self._run("merge-base", "--is-ancestor", commit, self._cache_ref, check=False)
        if result.returncode not in (0, 1):
            raise LockError("Git state publication outcome is unknown: ancestry check failed")
        return result.returncode == 0

    def _record_published(self, commit: str | None, updates: Sequence[RefUpdate]) -> None:
        changes: dict[str, str | None] = {}
        if commit is not None:
            self._base_oid = commit
            self._cached_state = commit
            changes[self._cache_ref] = commit
        for ref, new, _ in updates:
            if not ref.startswith(self._heartbeat_prefix):
                continue
            key = ref[len(self._heartbeat_prefix) :]
            changes[f"{self._heartbeat_cache_prefix}{key}"] = new
            self._heartbeat_errors.pop(key, None)
            if new is None:
                self._heartbeat_refs.pop(key, None)
                self._heartbeat_payloads.pop(key, None)
            else:
                self._heartbeat_refs[key] = new
                self._heartbeat_payloads[key] = self._written.pop(new, None)
        self._update_local_refs(changes)

    def _renew_heartbeats(self, beats: Sequence[Heartbeat]) -> None:
        if self._open != "renewal":
            raise LockError("Heartbeats are renewed inside renewal_view()")
        updates: list[RefUpdate] = []
        for beat in beats:
            key = heartbeat_key(beat.task_id)
            expected = self._heartbeat_refs.get(key)
            updates.append(
                (f"{self._heartbeat_prefix}{key}", self._heartbeat_commit(beat, expected), expected)
            )
        if updates:
            self._push_refs(updates)
            self._record_published(None, updates)

    # ------------------------------------------------------------------
    # Transactions and views
    # ------------------------------------------------------------------

    @contextmanager
    def lock(self, timeout: float = 10.0, blocking: bool = True) -> Generator[None, None, None]:
        """Run one optimistic read-write transaction.

        No remote lease is taken. On exit the state commit, plus the heartbeat
        refs staged for new and ended claims, is pushed atomically with
        expected OIDs. ``StateConflictError`` means another writer published
        first and nothing of this transaction landed; rerun it on fresh state.
        ``timeout`` and ``blocking`` apply to the local cache lock.
        """
        local_timeout = timeout if blocking else 0
        try:
            with self._cache_lock.acquire(timeout=local_timeout):
                self._sync()
                generation = self._bump_generation()
                self._clean = None
                self._open = "write"
                self._staged = None
                self._notifications = []
                self._bound_oid = None
                try:
                    yield
                    commit = self._commit_state()
                    if commit is not None:
                        updates: list[RefUpdate] = [(self._state_ref, commit, self._base_oid)]
                        updates.extend(self._staged_heartbeat_updates())
                        self._push_refs(updates)
                        self._record_published(commit, updates)
                    notifications = self._notifications
                finally:
                    self._open = None
                    self._staged = None
                    self._notifications = []
                    self._written.clear()
                # The worktree now equals the published (or unchanged) base.
                self._mark_clean(self._base_oid, generation)
                self._bound_oid = self._base_oid
                for notifier, token in notifications:
                    notifier.notify(token)
        except Timeout as exc:
            raise LockContentionError("Could not acquire local Git storage cache lock") from exc

    @contextmanager
    def read_snapshot(
        self, timeout: float = 10.0, blocking: bool = True
    ) -> Generator[None, None, None]:
        """Read one complete remote state without writing anything remote.

        Holds only the local cache lock, materializes the current state ref
        and heartbeats and yields; graph, events, tokens, content and
        heartbeats read inside all come from :attr:`state_oid` and the same
        ref read. It never pushes. A failed ref read or fetch raises instead
        of serving the previous cache, and corrupt data fails like any other
        read. Changing data inside the snapshot is an error.
        """
        with self._view(fresh=True, mode="read", timeout=timeout, blocking=blocking):
            yield

    @contextmanager
    def renewal_view(
        self, *, fresh: bool = True, timeout: float = 10.0, blocking: bool = True
    ) -> Generator[None, None, None]:
        """Yield state and heartbeats for one heartbeat renewal.

        ``fresh=False`` serves the last synchronized cache without a remote
        call; ``heartbeats.renew`` still pushes with the cached heartbeat as
        the expected OID, so a renewal based on outdated data is rejected.
        """
        with self._view(fresh=fresh, mode="renewal", timeout=timeout, blocking=blocking):
            yield

    @contextmanager
    def _view(
        self, *, fresh: bool, mode: str, timeout: float, blocking: bool
    ) -> Generator[None, None, None]:
        local_timeout = timeout if blocking else 0
        try:
            with self._cache_lock.acquire(timeout=local_timeout):
                if mode == "renewal":
                    # Renewals read the cached commit objects, never the worktree.
                    if fresh:
                        self._sync(materialize=False)
                    else:
                        self._read_cache_refs()
                    self._open = mode
                    try:
                        yield
                    finally:
                        self._open = None
                        self._written.clear()
                    return
                self._sync()
                bound = self._bound_oid
                self._bound_oid = None
                self._open = mode
                try:
                    yield
                finally:
                    self._open = None
                if self._worktree_tree() != self._base_tree():
                    self._bump_generation()
                    self._clean = None
                    raise LockError("Git read-only snapshot was modified; nothing was published")
                self._bound_oid = bound
        except Timeout as exc:
            raise LockContentionError("Could not acquire local Git storage cache lock") from exc

    def compact(self) -> str:
        """Archive current history and publish an equivalent root snapshot.

        The archive ref and the new root are pushed atomically against the
        state OID that was archived; a concurrent write makes it retry.
        """
        for attempt in range(5):
            try:
                with self._cache_lock.acquire(timeout=10):
                    self._sync()
                    old_oid = self._base_oid
                    if old_oid is None:
                        raise LockError("Cannot compact an unwritten Git namespace")
                    archive_ref = f"refs/heads/cascade-archive/{self.namespace}/{old_oid[:12]}"
                    archived_oid = self._remote_ref_oid(archive_ref)
                    if archived_oid not in (None, old_oid):
                        raise LockError(
                            f"Git archive ref {archive_ref} points to an unexpected commit"
                        )
                    message = self._state_message(
                        "cascade compacted state", f"archived_from={old_oid}"
                    )
                    compacted = self._run(
                        "commit-tree", self._base_tree(), input_text=message
                    ).stdout.strip()
                    updates: list[RefUpdate] = [(self._state_ref, compacted, old_oid)]
                    if archived_oid is None:
                        updates.append((archive_ref, old_oid, None))
                    self._push_refs(updates)
                    self._record_published(compacted, [])
                    return archive_ref
            except Timeout as exc:
                raise LockContentionError("Could not acquire local Git storage cache lock") from exc
            except StateConflictError:
                if attempt == 4:
                    raise
                time.sleep(0.1 * 2**attempt)
        raise AssertionError("unreachable")

    def exists(self) -> bool:
        return self._file.exists()

    def next_lamport(self) -> int:
        return self._file.next_lamport()

    def observe(self, remote_ts: int) -> None:
        self._file.observe(remote_ts)

    def load(self) -> Cascade | None:
        if self._open == "renewal":
            return self._load_cached_commit()
        return self._file.load()

    def _load_cached_commit(self) -> Cascade | None:
        """Claims and states of the cached commit; artifact texts are not loaded."""
        if self._cached_state is None:
            return None
        raw = self._run("cat-file", "-p", f"{self._cached_state}:data/graph.json").stdout
        try:
            graph_data = json.loads(raw)
            graph, _ = deserialize_graph(graph_data, _NoContent())
        except (KeyError, AttributeError, TypeError, ValueError) as exc:
            raise StorageCorruptionError(
                f"invalid graph structure: {exc}", path=f"{self._cached_state}:data/graph.json"
            ) from exc
        return graph

    def save(self, cascade: Cascade) -> None:
        self._file.save(cascade)

    def backup_corrupt(self) -> str | None:
        return self._file.backup_corrupt()

    def delete(self) -> None:
        self._file.delete()
