# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Full and incremental verification of an event log against its snapshot.

``verify_log`` checks a whole log: every line parses, the hash chain holds
from the first event, and replaying all events reproduces the snapshot
(``replay.verify`` differences and equal edge contracts).

``verify_appended`` starts from the ``LogCheckpoint`` of a log that already
passed. When the new log begins with exactly the verified bytes, only the
appended lines are parsed, chained from the checkpoint's head hash and
replayed on its state. Otherwise it runs ``verify_log``. Either way the
result fields are the ones ``verify_log`` would give for the same bytes,
snapshot and content, including line numbers and event indexes in messages.
"""

from __future__ import annotations

import copy
import hashlib
import json
from dataclasses import dataclass, field, replace
from typing import Any

from cascade.core.cascade import Cascade
from cascade.events import Event, check_chain
from cascade.replay import compare_snapshot, replay_from
from cascade.storage._serde import deserialize_graph, serialize_graph
from cascade.storage.content import ContentStore
from cascade.storage.protocol import StorageProtocol

CHECKPOINT_VERSION = 1


def _digest(text: str | None) -> str:
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class LogCheckpoint:
    """What a passing verification established, to verify later appends against.

    ``state`` is the replay of the verified events; it is copied before use
    and must not be changed. ``artifacts`` maps every content ref the replay
    resolved to a digest of the text it got, because replay reads artifact
    text from the content store of the snapshot being verified.
    """

    oid: str | None
    events: int
    lines: int
    byte_length: int
    prefix_sha256: str
    head_hash: str
    state: Cascade
    artifacts: dict[str, str]
    # Set once ``verify_appended(..., consume=True)`` has taken over ``state``.
    _used: list[bool] = field(default_factory=lambda: [False], repr=False, compare=False)

    @property
    def consumed(self) -> bool:
        return self._used[0]

    def to_dict(self) -> dict[str, Any]:
        """A JSON-compatible form for keeping checkpoints across processes."""
        if self.consumed:
            raise ValueError("log checkpoint was consumed by a later verification")
        blobs = _Blobs({})
        graph = serialize_graph(self.state, 0, blobs)
        return {
            "version": CHECKPOINT_VERSION,
            "oid": self.oid,
            "events": self.events,
            "lines": self.lines,
            "byte_length": self.byte_length,
            "prefix_sha256": self.prefix_sha256,
            "head_hash": self.head_hash,
            "graph": graph,
            "blobs": blobs.texts,
            "artifacts": dict(self.artifacts),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LogCheckpoint:
        """Rebuild a checkpoint written by ``to_dict``; only load trusted files."""
        if data.get("version") != CHECKPOINT_VERSION:
            raise ValueError("unsupported log checkpoint version")
        state, _ = deserialize_graph(data["graph"], _Blobs(dict(data["blobs"])))
        return cls(
            oid=data["oid"],
            events=int(data["events"]),
            lines=int(data["lines"]),
            byte_length=int(data["byte_length"]),
            prefix_sha256=str(data["prefix_sha256"]),
            head_hash=str(data["head_hash"]),
            state=state,
            artifacts={str(k): str(v) for k, v in data["artifacts"].items()},
        )


@dataclass(frozen=True)
class LogVerification:
    """Outcome of verifying one log against one snapshot.

    ``events`` counts the events parsed (up to a corrupt line). ``corruption``
    explains a log that could not be parsed or replayed; then the chain and
    replay fields are not evaluated. ``prefix_preserved`` says whether the
    log still starts with the checkpoint's verified bytes (None without a
    checkpoint); ``incremental`` whether only appended events were checked.
    """

    events: int
    corruption: str
    chain_valid: bool
    chain_message: str
    replay_diffs: tuple[str, ...]
    contracts_match: bool
    prefix_preserved: bool | None
    incremental: bool
    checkpoint: LogCheckpoint | None

    @property
    def valid(self) -> bool:
        return (
            not self.corruption
            and self.chain_valid
            and not self.replay_diffs
            and self.contracts_match
        )

    def conclusion(self) -> tuple[Any, ...]:
        """The fields a full and an incremental verification must agree on."""
        return (
            self.valid,
            self.events,
            self.corruption,
            self.chain_valid,
            self.chain_message,
            self.replay_diffs,
            self.contracts_match,
        )


class _Blobs:
    """In-memory content store for checkpoint serialization."""

    def __init__(self, texts: dict[str, str]) -> None:
        self.texts = texts

    def put(self, content: str) -> str:
        ref = _digest(content)
        self.texts[ref] = content
        return ref

    def get(self, ref: str) -> str | None:
        return self.texts.get(ref)

    def exists(self, ref: str) -> bool:
        return ref in self.texts


class _Recording:
    """Content store wrapper that remembers what replay resolved."""

    def __init__(self, inner: ContentStore | None, seen: dict[str, str]) -> None:
        self._inner = inner
        self.seen = seen

    def put(self, content: str) -> str:
        raise ValueError("replay does not store content")

    def get(self, ref: str) -> str | None:
        text = self._inner.get(ref) if self._inner is not None else None
        self.seen[ref] = _digest(text)
        return text

    def exists(self, ref: str) -> bool:
        return self._inner is not None and self._inner.exists(ref)


def _parse(raw: bytes, first_line: int) -> tuple[list[Event], str]:
    """Parse JSON lines; stop at the first bad line with its whole-log line number."""
    events: list[Event] = []
    for number, line in enumerate(raw.split(b"\n"), first_line):
        stripped = line.strip()
        if not stripped:
            continue
        try:
            events.append(Event.from_dict(json.loads(stripped.decode("utf-8"))))
        except UnicodeDecodeError:
            return events, f"invalid event at line {number}: not UTF-8"
        except (json.JSONDecodeError, KeyError, ValueError, TypeError) as exc:
            return events, f"invalid event at line {number}: {exc}"
    return events, ""


def _corrupt(
    events: int, message: str, prefix_preserved: bool | None, incremental: bool = False
) -> LogVerification:
    return LogVerification(
        events=events,
        corruption=message,
        chain_valid=False,
        chain_message="",
        replay_diffs=(),
        contracts_match=False,
        prefix_preserved=prefix_preserved,
        incremental=incremental,
        checkpoint=None,
    )


def _finish(
    *,
    raw: bytes,
    events: int,
    chain: tuple[bool, str, str],
    state: Cascade,
    snapshot: Cascade,
    artifacts: dict[str, str],
    oid: str | None,
    prefix_preserved: bool | None,
    incremental: bool,
) -> LogVerification:
    chain_valid, chain_message, head_hash = chain
    diffs = tuple(compare_snapshot(state, snapshot))
    contracts_match = state.contracts == snapshot.contracts
    checkpoint = None
    if chain_valid and not diffs and contracts_match and (not raw or raw.endswith(b"\n")):
        checkpoint = LogCheckpoint(
            oid=oid,
            events=events,
            lines=raw.count(b"\n"),
            byte_length=len(raw),
            prefix_sha256=hashlib.sha256(raw).hexdigest(),
            head_hash=head_hash,
            state=state,
            artifacts=artifacts,
        )
    return LogVerification(
        events=events,
        corruption="",
        chain_valid=chain_valid,
        chain_message=chain_message,
        replay_diffs=diffs,
        contracts_match=contracts_match,
        prefix_preserved=prefix_preserved,
        incremental=incremental,
        checkpoint=checkpoint,
    )


def verify_log(
    raw: bytes,
    snapshot: Cascade,
    content: ContentStore | None = None,
    *,
    oid: str | None = None,
) -> LogVerification:
    """Verify a whole log (``EventStore.read_bytes()``) against its snapshot."""
    events, corruption = _parse(raw, 1)
    if corruption:
        return _corrupt(len(events), corruption, None)
    artifacts: dict[str, str] = {}
    try:
        state = replay_from(Cascade(), events, _Recording(content, artifacts))
    except Exception as exc:
        return _corrupt(len(events), f"replay failed: {type(exc).__name__}: {exc}", None)
    return _finish(
        raw=raw,
        events=len(events),
        chain=check_chain(events),
        state=state,
        snapshot=snapshot,
        artifacts=artifacts,
        oid=oid,
        prefix_preserved=None,
        incremental=False,
    )


def verify_appended(
    previous: LogCheckpoint,
    raw: bytes,
    snapshot: Cascade,
    content: ContentStore | None = None,
    *,
    oid: str | None = None,
    consume: bool = False,
) -> LogVerification:
    """Verify ``raw`` given a checkpoint of an earlier, already verified log.

    The result equals ``verify_log(raw, snapshot, content)`` in every field of
    ``conclusion()``. Only events after the checkpoint are parsed and replayed
    when the log still starts with the verified bytes and every artifact the
    checkpoint replay read still has the same text; otherwise the whole log is
    verified and ``prefix_preserved`` tells whether the verified bytes survived.

    Copying the checkpoint's state dominates the cost on large graphs. With
    ``consume=True`` the state is replayed in place instead and ``previous``
    cannot be used again; pass the new result's checkpoint next time.
    """
    if previous.consumed:
        raise ValueError("log checkpoint was consumed by a later verification")
    length = previous.byte_length
    preserved = (
        len(raw) >= length and hashlib.sha256(raw[:length]).hexdigest() == previous.prefix_sha256
    )
    unchanged_artifacts = preserved and all(
        _digest(content.get(ref) if content is not None else None) == digest
        for ref, digest in previous.artifacts.items()
    )
    if not unchanged_artifacts:
        return replace(verify_log(raw, snapshot, content, oid=oid), prefix_preserved=preserved)
    appended, corruption = _parse(raw[length:], previous.lines + 1)
    total = previous.events + len(appended)
    if corruption:
        return _corrupt(total, corruption, True, incremental=True)
    artifacts = dict(previous.artifacts)
    if consume:
        previous._used[0] = True
        state = previous.state
    else:
        state = copy.deepcopy(previous.state)
    try:
        replay_from(
            state,
            appended,
            _Recording(content, artifacts),
            earlier=lambda: _parse(raw[:length], 1)[0],
        )
    except Exception as exc:
        return _corrupt(
            total, f"replay failed: {type(exc).__name__}: {exc}", True, incremental=True
        )
    return _finish(
        raw=raw,
        events=total,
        chain=check_chain(appended, previous.head_hash, previous.events),
        state=state,
        snapshot=snapshot,
        artifacts=artifacts,
        oid=oid,
        prefix_preserved=True,
        incremental=True,
    )


def verify_storage(
    storage: StorageProtocol, previous: LogCheckpoint | None = None, *, consume: bool = False
) -> tuple[Cascade | None, LogVerification]:
    """Inside ``lock()`` or ``read_snapshot()``: load the snapshot and verify its log.

    Pass the checkpoint of the last verified read to check only what was
    appended since. A Git storage's checkpoint records its ``state_oid``.
    """
    snapshot = storage.load()
    raw = storage.events.read_bytes()
    oid = getattr(storage, "state_oid", None)
    graph = snapshot if snapshot is not None else Cascade()
    if previous is None:
        return snapshot, verify_log(raw, graph, storage.content, oid=oid)
    return snapshot, verify_appended(
        previous, raw, graph, storage.content, oid=oid, consume=consume
    )
