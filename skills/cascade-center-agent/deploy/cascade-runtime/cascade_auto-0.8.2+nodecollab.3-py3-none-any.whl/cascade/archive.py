# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Cascade archive — snapshot cascade instances to ~/.cascade/archives/.

Not a graph operation. Operates at the file level: copies .cascade/
contents to a global archive directory and maintains an append-only
registry for querying.
"""

import json
import shutil
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from cascade.types import Result

_DEFAULT_HOME = Path.home() / ".cascade"


@dataclass(slots=True)
class ArchiveMeta:
    id: str
    source_path: str
    archived_at: float
    description: str
    node_count: int
    completed: int
    failed: int
    cancelled: int
    event_count: int


def _read_graph_stats(graph_path: Path) -> dict[str, int]:
    data = json.loads(graph_path.read_text(encoding="utf-8"))
    nodes = data.get("nodes", {})
    stats = {"total": len(nodes), "completed": 0, "failed": 0, "cancelled": 0}
    for node_data in nodes.values():
        state = node_data.get("state", "")
        if state == "COMPLETED":
            stats["completed"] += 1
        elif state == "FAILED":
            stats["failed"] += 1
        elif state == "CANCELLED":
            stats["cancelled"] += 1
    return stats


def _count_events(events_path: Path) -> int:
    if not events_path.exists():
        return 0
    count = 0
    with events_path.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                count += 1
    return count


def archive(
    source_dir: Path | str,
    *,
    description: str = "",
    home_dir: Path | None = None,
) -> Result:
    """Snapshot current .cascade/ to ~/.cascade/archives/{id}/."""
    source = Path(source_dir).resolve()
    home = home_dir or _DEFAULT_HOME

    graph_path = source / "graph.json"
    if not graph_path.exists():
        return Result(success=False, message="No cascade data to archive (graph.json not found)")

    stats = _read_graph_stats(graph_path)
    event_count = _count_events(source / "events.jsonl")

    archive_id = uuid.uuid4().hex[:12]
    archive_dir = home / "archives" / archive_id
    archive_dir.mkdir(parents=True, exist_ok=True)

    shutil.copy2(graph_path, archive_dir / "graph.json")

    events_path = source / "events.jsonl"
    if events_path.exists():
        shutil.copy2(events_path, archive_dir / "events.jsonl")

    artifacts_dir = source / "artifacts"
    if artifacts_dir.is_dir():
        shutil.copytree(artifacts_dir, archive_dir / "artifacts")

    workspace_path = str(source.parent)
    meta = ArchiveMeta(
        id=archive_id,
        source_path=workspace_path,
        archived_at=time.time(),
        description=description,
        node_count=stats["total"],
        completed=stats["completed"],
        failed=stats["failed"],
        cancelled=stats["cancelled"],
        event_count=event_count,
    )

    (archive_dir / "meta.json").write_text(
        json.dumps(asdict(meta), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    registry_path = home / "registry.jsonl"
    home.mkdir(parents=True, exist_ok=True)
    with registry_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(asdict(meta), ensure_ascii=False) + "\n")

    return Result(
        success=True,
        message=f"Archived to {archive_id}",
        data={
            "archive_id": archive_id,
            "archive_path": str(archive_dir),
            "node_count": stats["total"],
            "completed": stats["completed"],
            "failed": stats["failed"],
            "cancelled": stats["cancelled"],
            "event_count": event_count,
        },
    )


def list_archives(
    *,
    workspace_path: str | None = None,
    home_dir: Path | None = None,
) -> Result:
    """List archived cascade instances, optionally filtered by workspace."""
    home = home_dir or _DEFAULT_HOME
    registry_path = home / "registry.jsonl"

    if not registry_path.exists():
        return Result(
            success=True,
            message="No archives found",
            data={"archives": [], "count": 0},
        )

    archives: list[dict[str, Any]] = []
    with registry_path.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue
            if workspace_path and entry.get("source_path") != workspace_path:
                continue
            archives.append(entry)

    archives.sort(key=lambda x: x.get("archived_at", 0), reverse=True)

    return Result(
        success=True,
        message=f"{len(archives)} archive(s) found",
        data={"archives": archives, "count": len(archives)},
    )


def get_archive(
    archive_id: str,
    *,
    home_dir: Path | None = None,
) -> Result:
    """Get details of a specific archive."""
    home = home_dir or _DEFAULT_HOME
    archive_dir = home / "archives" / archive_id
    meta_path = archive_dir / "meta.json"

    if not meta_path.exists():
        return Result(success=False, message=f"Archive {archive_id} not found")

    meta = json.loads(meta_path.read_text(encoding="utf-8"))

    events_summary: dict[str, int] = {}
    events_path = archive_dir / "events.jsonl"
    if events_path.exists():
        with events_path.open(encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                    etype = event.get("type", "unknown")
                    events_summary[etype] = events_summary.get(etype, 0) + 1
                except json.JSONDecodeError:
                    continue

    nodes_list: list[dict[str, str]] = []
    graph_path = archive_dir / "graph.json"
    if graph_path.exists():
        graph_data = json.loads(graph_path.read_text(encoding="utf-8"))
        for nid, node_data in graph_data.get("nodes", {}).items():
            nodes_list.append({"id": nid, "state": node_data.get("state", "UNKNOWN")})

    return Result(
        success=True,
        message=f"Archive {archive_id}",
        data={
            "meta": meta,
            "events_summary": events_summary,
            "nodes": nodes_list,
        },
    )
