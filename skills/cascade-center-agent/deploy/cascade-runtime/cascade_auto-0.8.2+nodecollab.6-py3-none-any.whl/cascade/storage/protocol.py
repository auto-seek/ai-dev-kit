# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Storage protocols — interfaces any Cascade backend must implement.

Each sub-component (events, tokens, ops, content) is a protocol.
FileStorage provides file-based implementations; distributed backends
(Postgres, Redis) provide their own.
"""

from collections.abc import Generator, Mapping, Sequence
from contextlib import contextmanager
from typing import Any, Protocol, runtime_checkable

from cascade.core.cascade import Cascade
from cascade.events import Event, EventType
from cascade.storage.content import ContentStore
from cascade.storage.token_store import CancelNotifier
from cascade.types import Heartbeat, TokenStatus

# ---------------------------------------------------------------------------
# Sub-component protocols
# ---------------------------------------------------------------------------


@runtime_checkable
class EventStoreProtocol(Protocol):
    """Append-only event log with query methods.

    Core methods (emit, read_all, clear, count, verify_chain) must be
    implemented by every backend. Query methods have default implementations
    in EventStoreQueries that delegate to read_all() — remote backends
    can inherit those or override with native queries.
    """

    def emit(
        self, event_type: EventType, logical_ts: int, *, trace_id: str = "", **data: Any
    ) -> Event: ...

    def read_all(self) -> list[Event]: ...

    def read_since(self, since: float) -> list[Event]: ...

    def read_at(self, logical_ts: int) -> Event | None: ...

    def read_range(self, from_ts: int, to_ts: int) -> list[Event]: ...

    def read_until(self, until_ts: int) -> list[Event]: ...

    def read_by_type(self, event_type: EventType) -> list[Event]: ...

    def read_by_trace(self, trace_id: str) -> list[Event]: ...

    def read_by_node(self, node_id: str) -> list[Event]: ...

    def summary(self) -> dict[str, int]: ...

    def clear(self) -> None: ...

    @property
    def count(self) -> int: ...

    def verify_chain(self) -> tuple[bool, str]: ...

    def read_bytes(self) -> bytes:
        """The stored log as JSON lines, for byte-exact incremental verification."""
        ...


@runtime_checkable
class TokenStoreProtocol(Protocol):
    """Task claim token storage."""

    def create(
        self,
        node_id: str,
        agent_id: str,
        claimed_at: float,
        notifier: "CancelNotifier | None" = None,
    ) -> TokenStatus: ...

    def check(self, node_id: str) -> TokenStatus | None: ...

    def invalidate(self, node_id: str, reason: str) -> TokenStatus | None: ...

    def cleanup(self, node_id: str) -> None: ...


@runtime_checkable
class HeartbeatStoreProtocol(Protocol):
    """Per-claim lease heartbeats, kept outside the graph and the event log."""

    def make(
        self,
        task_id: str,
        agent_id: str,
        claim_token: int,
        renewed_at: float,
        timeout: float | None,
    ) -> Heartbeat:
        """A heartbeat stamped with this store's namespace and runtime."""
        ...

    def current(self) -> dict[str, Heartbeat]:
        """Well-formed heartbeats by task ID, as of the open transaction or view.

        A heartbeat may belong to an older claim; apply it only through
        ``Node.heartbeat_applies`` and the ``Node.lease_*`` methods.
        """
        ...

    def malformed(self) -> list[dict[str, str]]:
        """Stored heartbeats that cannot be used, each with ``key`` and ``reason``.

        They count as absent for every expiry decision; reads report them.
        """
        ...

    def stage(self, started: Sequence[Heartbeat], active: Mapping[str, tuple[str, int]]) -> None:
        """Inside ``lock()``: publish heartbeats with the transaction's commit.

        ``started`` are first heartbeats of claims this transaction created.
        ``active`` maps every ACTIVE task after the transaction to its
        ``(agent_id, claim_token)``; any other heartbeat is removed.
        """
        ...

    def renew(self, beats: Sequence[Heartbeat]) -> None:
        """Inside ``renewal_view()``: replace these tasks' heartbeats at once.

        Each replaced heartbeat must still be the version the view showed;
        otherwise nothing changes and ``StateConflictError`` is raised.
        """
        ...


@runtime_checkable
class OpLogProtocol(Protocol):
    """Idempotent operation log."""

    def get(self, op_id: str) -> dict[str, Any] | None: ...

    def record(self, op_id: str, result: dict[str, Any]) -> None: ...


# ---------------------------------------------------------------------------
# Event query mixin — convenience methods built on read_all()
# ---------------------------------------------------------------------------


class EventStoreQueries:
    """Query methods any EventStore gets for free.

    Subclass this alongside your EventStore implementation, or use
    it standalone. All methods delegate to self.read_all().
    """

    def read_all(self) -> list[Event]:
        raise NotImplementedError

    def read_since(self, since: float) -> list[Event]:
        return [e for e in self.read_all() if e.timestamp > since]

    def read_at(self, logical_ts: int) -> Event | None:
        for e in self.read_all():
            if e.logical_ts == logical_ts:
                return e
        return None

    def read_range(self, from_ts: int, to_ts: int) -> list[Event]:
        return [e for e in self.read_all() if from_ts <= e.logical_ts <= to_ts]

    def read_until(self, until_ts: int) -> list[Event]:
        return [e for e in self.read_all() if e.logical_ts <= until_ts]

    def read_by_type(self, event_type: EventType) -> list[Event]:
        return [e for e in self.read_all() if e.type == event_type]

    def read_by_trace(self, trace_id: str) -> list[Event]:
        return [e for e in self.read_all() if e.trace_id == trace_id]

    def read_by_node(self, node_id: str) -> list[Event]:
        return [
            e
            for e in self.read_all()
            if e.data.get("node_id") == node_id
            or e.data.get("source_node_id") == node_id
            or e.data.get("corrective_node_id") == node_id
            or node_id in e.data.get("new_node_ids", [])
        ]

    def summary(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for event in self.read_all():
            key = event.type.value
            counts[key] = counts.get(key, 0) + 1
        return counts


# ---------------------------------------------------------------------------
# Top-level storage protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class StorageProtocol(Protocol):
    """Interface for Cascade persistence backends.

    FileStorage is the built-in implementation (JSON + filelock).
    Distributed backends (Postgres, Redis, etc.) implement this
    same protocol.
    """

    # Read-only: a backend may build these on first use.
    @property
    def events(self) -> EventStoreProtocol: ...

    @property
    def tokens(self) -> TokenStoreProtocol: ...

    @property
    def ops(self) -> OpLogProtocol: ...

    @property
    def content(self) -> ContentStore: ...

    @property
    def heartbeats(self) -> HeartbeatStoreProtocol: ...

    def exists(self) -> bool: ...

    def next_lamport(self) -> int: ...

    def observe(self, remote_ts: int) -> None: ...

    @contextmanager
    def lock(self, timeout: float = 10.0, blocking: bool = True) -> Generator[None, None, None]: ...

    @contextmanager
    def read_snapshot(
        self, timeout: float = 10.0, blocking: bool = True
    ) -> Generator[None, None, None]:
        """Yield a consistent, single-version view for reads only.

        Graph, events, tokens and content read inside come from one committed
        state. Backends may skip their write lease here but must never expose a
        partially written transaction, publish anything, or serve stale data
        when the authoritative state cannot be read.
        """
        ...

    @contextmanager
    def renewal_view(
        self, *, fresh: bool = True, timeout: float = 10.0, blocking: bool = True
    ) -> Generator[None, None, None]:
        """Yield state and heartbeats for validating a heartbeat renewal.

        With ``fresh=False`` a backend may serve its last synchronized copy
        without contacting a remote; ``heartbeats.renew`` then still rejects a
        heartbeat that changed since. Nothing but heartbeats may be written.
        """
        ...

    def load(self) -> Cascade | None: ...

    def save(self, cascade: Cascade) -> None: ...

    def backup_corrupt(self) -> str | None: ...

    def delete(self) -> None: ...
