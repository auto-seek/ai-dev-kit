# Copyright 2026 Hangzhou Autoseek Information Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Client base — transaction infrastructure and fail-closed state loading."""

from __future__ import annotations

import copy
import math
import random
import subprocess
import time
import uuid
from collections.abc import Callable
from pathlib import Path
from typing import Any

from cascade.core.cascade import Cascade
from cascade.core.node import Node
from cascade.core.state import NodeState
from cascade.errors import StateConflictError, StorageCorruptionError
from cascade.events import EventType, reservation_activity
from cascade.storage.file_storage import FileStorage
from cascade.storage.protocol import StorageProtocol
from cascade.types import (
    Context,
    ErrorCode,
    Heartbeat,
    Result,
)

# A write that loses its compare-and-swap is redone on fresh state. Waits
# between attempts are drawn uniformly below a ceiling that doubles from 50 ms
# to 400 ms; redoing stops at the deadline, and the write then fails with
# STATE_CONFLICT having published nothing. The ceiling also shrinks with the
# time the write has already waited (halving about every second, down to
# 10 ms), so under a burst the writers that have waited longest fetch first
# after each published commit and win more often than newcomers, which still
# back off up to 400 ms. WRITE_ATTEMPTS only guards against a storage that
# fails instantly; fast attempts at the 10 ms floor reach the deadline first.
WRITE_ATTEMPTS = 100_000
WRITE_DEADLINE_SECONDS = 60.0
_WRITE_BACKOFF_INITIAL = 0.05
_WRITE_BACKOFF_MAX = 0.4
_WRITE_BACKOFF_FLOOR = 0.01
_WRITE_AGING_SECONDS = 1.5


def _redo_ceiling(attempt: int, waited: float) -> float:
    """Upper bound of the wait before redo ``attempt`` (1-based) after ``waited`` seconds."""
    grown = _WRITE_BACKOFF_INITIAL * 2.0 ** min(attempt - 1, 16)
    aged = _WRITE_BACKOFF_MAX * math.exp(-waited / _WRITE_AGING_SECONDS)
    return max(_WRITE_BACKOFF_FLOOR, min(_WRITE_BACKOFF_MAX, grown, aged))


def _active_claims(graph: Cascade) -> dict[str, tuple[str, int]]:
    """ACTIVE task ID -> (agent_id, claim_token) for every fenced claim."""
    return {
        node.id: (node.agent_id, node.claim_token)
        for node in graph.nodes.values()
        if node.state == NodeState.ACTIVE
        and node.agent_id is not None
        and node.claim_token is not None
    }


class _Tx:
    """Mutation transaction — holds graph, handles emit/save/op_id.

    ``heartbeats`` are the claim heartbeats read with this attempt's state.
    """

    def __init__(
        self,
        graph: Cascade,
        storage: StorageProtocol,
        op_id: str | None,
        heartbeats: dict[str, Heartbeat] | None = None,
    ):
        self.graph = graph
        self._storage = storage
        self._op_id = op_id
        self.heartbeats = heartbeats or {}
        self._dirty = False
        self._trace_id = uuid.uuid4().hex
        self._task_inputs = {
            node.id: copy.deepcopy((node.task_input, node.publication, node.required_tier))
            for node in graph.nodes.values()
            if node.task_input is not None
        }

    def _validate_task_inputs(self) -> None:
        for node_id, expected in self._task_inputs.items():
            node = self.graph.nodes.get(node_id)
            if node is None or (node.task_input, node.publication, node.required_tier) != expected:
                raise ValueError(
                    "Published task inputs are immutable; cancel and publish a replacement"
                )
        for node in self.graph.nodes.values():
            if node.task_input is not None:
                actual = {a for a, b in self.graph.contracts if b == node.id}
                if actual != set(node.task_input["brief"]["dependencies"]):
                    raise ValueError(
                        "Published task dependencies are immutable; publish a replacement"
                    )

    def emit(self, event_type: EventType, **data: Any) -> None:
        self._validate_task_inputs()
        self._storage.events.emit(
            event_type,
            logical_ts=self._storage.next_lamport(),
            trace_id=self._trace_id,
            epoch=self.graph.epoch,
            **data,
        )
        self._dirty = True

    def save(self) -> None:
        self._validate_task_inputs()
        self._storage.save(self.graph)

    def heartbeat(self, node: Node) -> Heartbeat | None:
        """The node's heartbeat if it belongs to the current claim."""
        heartbeat = self.heartbeats.get(node.id)
        return heartbeat if node.heartbeat_applies(heartbeat) else None

    def ok(self, result: Result) -> Result:
        """Finalize a successful mutation: save graph, record op, return result."""
        if self._dirty:
            self._storage.save(self.graph)
        if self._op_id is not None:
            self._storage.ops.record(self._op_id, result.to_dict())
        return result


class ClientBase:
    """Transaction infrastructure shared by all client mixins."""

    def __init__(self, storage: StorageProtocol | str | Path = ".cascade"):
        if isinstance(storage, (str, Path)):
            self._storage: StorageProtocol = FileStorage(storage)
        else:
            self._storage = storage

    def _cached_op(self, op_id: str | None) -> Result | None:
        """Read a receipt inside the caller's existing mutation transaction."""
        if op_id is None:
            return None
        cached = self._storage.ops.get(op_id)
        if cached is not None:
            return Result.from_dict(cached)
        return None

    def _load_graph(self) -> Cascade:
        """Load graph under the lock or a read snapshot; surface corruption."""
        graph = self._storage.load()
        if graph is None and self._storage.events.count:
            raise StorageCorruptionError(
                "snapshot is missing while the event log exists; restore a verified snapshot"
            )
        return graph if graph is not None else Cascade()

    def load(self) -> Cascade:
        """Load the current graph. Corrupt state raises without modifying evidence."""
        with self._storage.read_snapshot():
            return self._load_graph()

    def _transact(self, body: Callable[[_Tx], Result], op_id: str | None = None) -> Result:
        """Run ``body`` as one optimistic transaction, redoing it after a lost CAS.

        ``body`` may run several times, each time on freshly synchronized
        state, so every effect must go through ``tx`` or storage: those are
        discarded with a lost attempt. Timestamps, fencing tokens and receipt
        lookups are recomputed on each run. Claims the body creates or ends
        are staged as heartbeat changes of the same commit.
        """
        started = time.monotonic()
        deadline = started + WRITE_DEADLINE_SECONDS
        conflict: StateConflictError | None = None
        for attempt in range(WRITE_ATTEMPTS):
            if attempt:
                now = time.monotonic()
                delay = random.uniform(0, _redo_ceiling(attempt, now - started))
                if now + delay > deadline:
                    break
                time.sleep(delay)
            try:
                with self._storage.lock():
                    graph = self._load_graph()
                    before = _active_claims(graph)
                    tx = _Tx(graph, self._storage, op_id, self._storage.heartbeats.current())
                    result = body(tx)
                    self._stage_claims(tx, before)
                    return result
            except StateConflictError as error:
                conflict = error
        return Result(
            success=False,
            message=(
                f"Write lost to concurrent writers on every attempt; nothing was "
                f"published: {conflict}"
            ),
            code=ErrorCode.STATE_CONFLICT,
        )

    def _stage_claims(self, tx: _Tx, before: dict[str, tuple[str, int]]) -> None:
        """Give new claims a first heartbeat and drop heartbeats of ended ones."""
        active = _active_claims(tx.graph)
        started = []
        for task_id, (agent_id, token) in active.items():
            if before.get(task_id) == (agent_id, token):
                continue
            node = tx.graph.nodes[task_id]
            claimed_at = node.claimed_at if node.claimed_at is not None else time.time()
            started.append(
                self._storage.heartbeats.make(
                    task_id, agent_id, token, renewed_at=claimed_at, timeout=node.timeout
                )
            )
        self._storage.heartbeats.stage(started, active)

    def _expire_reservations(self, tx: _Tx, now: float, task_id: str | None = None) -> list[str]:
        """Release idle READY reservations using durable task activity evidence."""
        candidates = {
            node.id: node
            for node in tx.graph.nodes.values()
            if node.state == NodeState.READY
            and node.reserved_for is not None
            and (task_id is None or node.id == task_id)
        }
        if not candidates:
            return []
        activity = reservation_activity(self._storage.events.read_all())
        expired = []
        # Validate all candidates before emitting or changing any reservation.
        for node_id in candidates:
            last_activity = activity.get(node_id)
            if last_activity is None or not math.isfinite(last_activity.timestamp):
                raise StorageCorruptionError(
                    f"Cannot determine reservation age for {node_id}; restore its task history"
                )
            if (
                last_activity.type == EventType.TASK_TIMED_OUT
                or now - last_activity.timestamp >= 1800
            ):
                expired.append(node_id)
        for node_id in expired:
            node = candidates[node_id]
            event = activity[node_id]
            previous = node.reserved_for
            node.reserved_for = None
            tx.emit(
                EventType.NODE_EDITED,
                node_id=node_id,
                changes=["reservation expired"],
                reason="Execution lease expired"
                if event.type == EventType.TASK_TIMED_OUT
                else "Reservation inactive for 1800 seconds",
                reservation_expired={
                    "reserved_for": previous,
                    "activity_event_id": event.id,
                    "activity_at": event.timestamp,
                    "timeout_seconds": 1800,
                },
            )
        return expired

    @property
    def storage(self) -> StorageProtocol:
        return self._storage


# ---------------------------------------------------------------------------
# Module-private helpers
# ---------------------------------------------------------------------------


def _get_git_ref() -> str:
    """Get current HEAD commit hash, or empty string if not in a git repo."""
    try:
        r = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if r.returncode == 0:
            return r.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        pass
    return ""


def _update_context(
    node: Node,
    *,
    summary: str = "",
    critical: dict[str, Any] | None = None,
    artifacts: str = "",
    merge_mode: str = "merge",
) -> bool:
    """Update node context based on params. Returns True if context was updated."""
    if critical is None and not summary and not artifacts:
        return False

    if node.context is None:
        node.context = Context()

    ctx = node.context

    if merge_mode == "replace":
        if critical is not None:
            ctx.critical = dict(critical)
        if summary:
            ctx.summary = summary
        if artifacts:
            ctx.artifacts = str(artifacts)
    elif merge_mode == "append":
        if critical is not None:
            ctx.critical.update(critical)
        if summary:
            ctx.summary = (ctx.summary + "\n" + summary).strip()
        if artifacts:
            ctx.artifacts = str(artifacts)
    else:  # merge (default)
        if critical is not None:
            ctx.critical.update(critical)
        if summary:
            if ctx.summary:
                ctx.summary = ctx.summary + "\n" + summary
            else:
                ctx.summary = summary
        if artifacts:
            ctx.artifacts = str(artifacts)

    return True
